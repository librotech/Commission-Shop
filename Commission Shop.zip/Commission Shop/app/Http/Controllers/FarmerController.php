<?php

namespace App\Http\Controllers;

use App\Farmer;
use Illuminate\Http\Request;
use App\Chartofaccount;
use DB;
use Auth;

class FarmerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    Public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {    

        $farmers = Farmer::all(); 
         return view('farmer.view' , ['farmers'=> $farmers]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $auto_increment=DB::select("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA ='".env('DB_DATABASE')."' AND TABLE_NAME ='farmers'");
        $farmers = DB::Table('farmers')->orderBy('farmers_id' , 'desc')->first();
        return view('farmer.add' , compact('farmers' , 'auto_increment'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate( $request , [
            'txt_farmer_id'=>'required',
            'txt_farmer_name'=>'required'
        ]);
        $check_duplicate=Farmer::where('farmers_id',$request->txt_farmer_id)->first();
        if($check_duplicate !== null){
            $request->session()->flash('message.level', 'danger');
            $request->session()->flash('message.content', 'This Farmer Already Available Please Try Changed Farmer Id');
            return redirect('farmer/add');
         }       
        else{
        $farmer = new Farmer;
        $farmer->farmers_id = $request->txt_farmer_id;
        $farmer->farmers_name = $request->txt_farmer_name;
        $farmer->father_name = $request->txt_father_name;
        $farmer->user_id  =Auth::id();
        $farmer->address = $request->txt_farmer_address;
        $farmer->contact_no = $request->txt_farmer_contact;
         if ($farmer->save()) {
            $this->farmer_chart_of_account('farmer_'.$request->txt_farmer_id,$request->txt_farmer_name,$request->txt_farmer_name." account");
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'New farmer was successfully added!');
        }
        return redirect('farmer/add');
    }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Farmer  $farmer
     * @return \Illuminate\Http\Response
     */
    public function show( $id)
    {
       $single_farmer = DB::table('farmers')->where('farmers_id' , $id)->get();
       // return $single_farmer;
       return view('farmer.edit',['single_farmer'=>$single_farmer]);  
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Farmer  $farmer
     * @return \Illuminate\Http\Response
     */
    public function edit(Farmer $farmer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Farmer  $farmer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Farmer $farmer)
    {
        $this->validate($request , [

            'txt_farmer_name'     => 'required',
            'txt_father_name'     => 'required',
            'contact'             => 'required',
            'address'             => 'required',
        ]);

        $update = DB::table('farmers')
        ->where('farmers_id' , $request->txt_farmer_id)
        ->update([
            'farmers_id'   => $request->txt_farmer_id,
            'farmers_name' => $request->txt_farmer_name,
            'father_name'  => $request->txt_father_name,
            'contact_no'   => $request->contact,
            'address'      => $request->address
        ]);
        if ($update) {
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Supplier Details successfully Updated!');
        }
        return redirect('farmer/show/'.$request->txt_farmer_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Farmer  $farmer
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
            
        $farmer = DB::table('farmers')->where('farmers_id' , $id)->delete();
        return redirect()->back();        
    }
     public function allfarmers(){
        $farmers=Farmer::all();

        echo"<option value=''>Select</option>";
        foreach ($farmers as $farmer) {

            echo "<option value=".$farmer->farmers_id.">".$farmer->farmers_id."</option>";
        }
        echo '<option value="add_supplier" class="btn btn-info">Add Farmer</option>';

    }
     public function farmer_chart_of_account($account_id,$account_title,$account_description){
        $chartofaccount=new Chartofaccount();
        $chartofaccount->coa_id=$account_id;
        $chartofaccount->coa_title=$account_title;
        $chartofaccount->account_type=2;
        $chartofaccount->coa_description=$account_description;
        $chartofaccount->user_id=Auth::id();
        if($chartofaccount->save()){
            app('App\Http\Controllers\ChartofaccountController')->log_chartofaccount($account_id,$account_title,$account_description,2);
        }
    }
}
