<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use DB;
use Auth;
use App\Chartofaccount;
use App\Inventory;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    Public function __construct(){
        $this->middleware('auth');
    }
    public function index()
    {
        $query=DB::raw('SELECT * From products LEFT JOIN users ON products.user_id = users.id');
    $products=DB::select($query);
        return view('product/view' , compact('products'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products=DB::table('products')->orderBy('product_id', 'desc')->first();
        return view('product.add',compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request,
            ['txt_product_id'=>'required',
            'txt_product_description'=>'required',
            'txt_sale_price'=>'required',
            // 'txt_stock_alert'=>'required',
            // 'txt_expiry_date'=>'required',
        ]);
        $check_duplicate=Product::where('product_id',$request->txt_product_id)->first();
        if($check_duplicate !== null){
            $request->session()->flash('message.level', 'danger');
            $request->session()->flash('message.content', 'This Product  Already Available Please Try Changed Product Id');
            return redirect('product/add');
        }
        else{
        $product=new Product;
        $product->product_id=$request->txt_product_id;
        $product->product_description=$request->txt_product_description;
        $product->sale_price=$request->txt_sale_price;
        // $product->stock_alert=$request->txt_stock_alert;
        $product->bag_price  = $request->txt_bag_quantity;

        $product->user_id=Auth::id();
        if ($product->save()) {
            $this->product_chart_of_account('product_'.$request->txt_product_id,'product_'.$request->txt_product_description,'product_'.$request->txt_product_description.'_account');
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'New Product was successfully added!');
        }
        return redirect('product/add');
        }
    }

    public function product_chart_of_account($account_id,$account_title,$account_description){
        $chartofaccount=new Chartofaccount();
        $chartofaccount->coa_id=$account_id;
        $chartofaccount->coa_title=$account_title;
        $chartofaccount->account_type=1;
        $chartofaccount->coa_description=$account_description;
        $chartofaccount->user_id=Auth::id();
        if($chartofaccount->save()){
            app('App\Http\Controllers\ChartofaccountController')->log_chartofaccount($account_id,$account_title,$account_description,1);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show($product_id)
    {
        $product =DB::table('products')->where('product_id',$product_id)->get();
        // return $product;
        return view('product/edit',['products'=>$product]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request,
            ['txt_product_id'=>'required',
            'txt_product_description'=>'required',
            'txt_sale_price'=>'required',
            // 'txt_stock_alert'=>'required'
        ]);
         $update=DB::table('products')
            ->where('id', $request->txt_rec_id)
            ->update(['product_id'=>$request->txt_product_id,'product_description' => $request->txt_product_description,'sale_price'=>$request->txt_sale_price]);
        if ($update) {
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Product Details successfully Updated!');
        }
        return redirect('product/show/'.$request->txt_rec_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($product)
    {
        DB::table('products')->where('product_id',$product)->delete();
        return redirect('product/show');
    }

    public function allproducts(){
        $products=Product::all();
        foreach ($products as $product) {
            echo "<option value=".$product->product_id.">".$product->product_description."</option>";
        }
    }
}
