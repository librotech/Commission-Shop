<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Http\Request;
use App\Attendence;
use App\Customer;
use App\Employeeadvance;
use App\Chartofaccount;
use Auth;
use App\Ledger;
use App\Farmer;
use DB;
use App\Payroll;
use App\Sale;
use App\Saleproduct;
use App\Product;
use App\Inventory;
class EmployeeController extends Ledgerfunctions
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $employees=Employee::get();
        return view('employees/view',compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('employees/add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    $check_duplicate=Employee::where('name','=',$request->name)->first();
        if($check_duplicate != null){
            $request->session()->flash('message.level', 'danger');
            $request->session()->flash('message.content', 'Employee With The Name Already Available');
            return redirect('employee/add');
        }
        else{
            
                $employees=new Employee;
                $employees->name=$request->name;
                $employees->salary=$request->salary;
                // $employees->shift=$request->shift;
                if(isset($request->mm) && $request->mm != ""){
                $employees->mm=true;
                }
                else{
                    $employees->mm=false;
                }
                $employees->available=true;
                if($employees->save()){
                $employee_id=Employee::orderby('id','desc')->first();
                // //expense chart of account
                // $this->employee_chart_of_account('expense_employee_'.$employee_id->id,$request->name,$request->name."expense_account",5);
                //liability chart of account 
                $this->employee_chart_of_account('liability_employee_'.$employee_id->id,$request->name,$request->name."liability_account",2);
                    $request->session()->flash('message.level', 'success');
                    $request->session()->flash('message.content', 'New employee Has Been Added');
                    
                } 
            return redirect('employee/add');
        }
        
    }
    public function employee_chart_of_account($account_id,$account_title,$account_description,$accounttype){
        $chartofaccount=new Chartofaccount();
        $chartofaccount->coa_id=$account_id;
        $chartofaccount->coa_title=$account_title;
        $chartofaccount->account_type=$accounttype;
        $chartofaccount->coa_description=$account_description;
        $chartofaccount->user_id=Auth::id();
        if($chartofaccount->save()){
            app('App\Http\Controllers\ChartofaccountController')->log_chartofaccount($account_id,$account_title,$account_description,5);
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show($employee)
    {
        $employee =employee::where('id',$employee)->get();
        return view('employees/edit',['employees'=>$employee]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        if(isset($request->available) && $request->available != ""){
            $available=true;
            }
            else{
                $available=false;
            }
        $update=Employee::where('id', $request->empid)
            ->update(['name'=>$request->name,'salary' => $request->salary,'available'=>$available]);
        if ($update) {
            $request->session()->flash('message.level', 'success');
            $request->session()->flash('message.content', 'Employee Details successfully Updated!');
        }
        return redirect('employee/view/'.$request->empid);
    }

      public function returnsale(Request $request){


        $transectiontype=1;

        $refrence_id = $request->inv;

        $date=date('Y-m-d');

        $this->Addinventory($request->pro,$request->inv,1,$request->total * $request->cost_price ,$request->total,$date);

        $this->assetledger('product_'.$request->pro,1,"assets" ,$request->total * $request->cost_price,null,$transectiontype,$request->inv,$date);

        $this->cost_sale_ledger($request->total * $request->cost_price, $refrence_id,$date,$request->date_bit);

        $this->sale_ledger($request->total * $request->cost_price,$refrence_id,$date,$request->date_bit);

        $this->assetledger('customer_'.$request->cus,1,"assets",null,$request->total * $request->cost_price,$transectiontype,$refrence_id,$date);
        
        // return $request->total * $request->cost_price;

        $request->session()->flash('message.level', 'success');
        $request->session()->flash('message.content', 'Sale Returned');
        return redirect('employees/returnsaleview');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy($employee)
    {
        Employee::where('id',$employee)->delete();
        return redirect('employee/view');
    }

  // public function updateShift(){
  //   foreach(Employee::all() as $employee){
  //       if($employee->shift == 'day')
  //           Employee::where('id',$employee->id)->update(['shift'=>'night']);
  //       else if($employee->shift == 'night')
  //           Employee::where('id',$employee->id)->update(['shift'=>'day']);
  //       }
  //       return redirect('employee/view');
  //   }

    // public function updateSingleShift(Request $request){
    //     Employee::where('id', $request->empid)
    //     ->update(['shift'=>$request->shift]);
    // }
    public function showattendenceform()
    {
        return view('employees/attendenceform');
    }

    public function showattenedce(Request $request){
       $employees=Employee::where('shift',$request->shift)->where('mm',false)->where('available',1)->get();
       return $employees;
    }

    public function showattenedcebydate(Request $request){
        return view('employees/allattendences');
    }
    public function allattendence(Request $request){
       return Attendence::select('attendences.*','employees.name')->Leftjoin('employees','attendences.empid','=','employees.id')->where('date',$request->date)->where('available',1)->get();
    }

    public function updateattendecs($employee,$date,$status){
        if($status == 1){
             $update = Attendence::where('empid',$employee)->whereDate('date',$date)->update(['attendence'=>false]);
             $this->reversestorestitchunitledger($employee,$date);
        }
        else if($status == 0){
           $update = Attendence::where('empid',$employee)->whereDate('date',$date)->update(['attendence'=>true]); 
           $this->storestitchunitledger($employee,"",$date);
           
        }
        return redirect('employee/showattenedcebydate');
        
    }
    public function doattendence($employee,$date){
        $dt1 = strtotime($date);
        $dt2 = date("l", $dt1);
        $dt3 = strtolower($dt2);
        $checkduplicate=Attendence::where('empid',$employee)->where('date',$date)->count();
        if($checkduplicate == null){
            $attendence=new Attendence;
            $attendence->empid=$employee;
            $attendence->attendence=true;
            
            $attendence->date=$date;
            if($dt3 == "friday"){
            $attendence->overtime=true;
            }
            else{
                $attendence->overtime=false;
            }
            $attendence->save();
            }
        }
        
        function storeAbsentEmployeesLedger($absentEmployees,$date){
            $countofdays=date('t',strtotime($date));
            $salaryamount = 0;
            foreach($absentEmployees as $aemp){
                $salary = Employee::where('id',$aemp->id)->where('employees.available',1)->first();
                if($salary != null){
                    $amounttobeentered=$salary->salary/$countofdays*0.5;
                    $salaryamount  +=$amounttobeentered;
                    $this->liabilityledger('liability_employee_'.$aemp->id,5,"liabilities",$this->roundFigure($amounttobeentered),null,10,$aemp->id,$date);
                }
            }
            
            if($salaryamount > 0)
                $this->expensledger('salary101',5,"expense",null,$this->roundFigure($salaryamount),10,1,$date);
            
        }
         public function storestitchunitledger($employee,$stitches,$date){
         $salary = Employee::where('id',$employee)->where('employees.available',1)->first();
         $countofdays=date('t',strtotime($date));
         $dt1 = strtotime($date);
         $dt2 = date("l", $dt1);
         $dt3 = strtolower($dt2);
         if($stitches != ""){
             if($dt3 == "friday"){
             $amounttobeentered=$salary->salary/$countofdays*1.5;
        
             }
             else{
                $amounttobeentered=($salary->salary/$countofdays);
             }
         }
         else{
             $amounttobeentered=($salary->salary/$countofdays);
         }
         $this->salaryamount +=$amounttobeentered;
         $this->liabilityledger('liability_employee_'.$employee,5,"liabilities",null,$this->roundFigure($amounttobeentered),10,$employee,$date);
        }
        public function doattendencefromattendenceform(Request $request){
        $dt1 = strtotime($request->date);
        $dt2 = date("l", $dt1);
        $dt3 = strtolower($dt2);
        for ($i=0; $i < count($request->empid); $i++) { 
        
        $checkduplicate=Attendence::where('empid',$request->empid[$i])->where('date',$request->date)->count();
        if($checkduplicate == null){
            $attendence=new Attendence;
            $attendence->empid=$request->empid[$i];
            if(isset($request->attend[$i])){
                $attendence->attendence=1;
            }
            
            else{
                $attendence->attendence=0;
            }
            $attendence->overtime=false;
            $attendence->date=$request->date;
            $attendence->save();
            if(isset($request->attend[$i]))
                $this->storestitchunitledgerfromattendenceform($request->empid[$i],$request->date);
            }
        }
        $this->expensledger('salary101',5,"expense",$this->roundFigure($this->salaryamount),null,10,1,$request->date);
        }
    
    public function reversestorestitchunitledger($employee,$date){
     $salary = Employee::where('id',$employee)->where('employees.available',1)->first();
    //  $countofdays=$this->countDays(2018,date('m',strtotime($date)), array(7, 5));
    $countofdays=date('t',strtotime($date));
     // $d=cal_days_in_month(CAL_GREGORIAN,date('m',strtotime($date)),date('Y',strtotime($date)));
     // $onedaysalary=$salary->salary/$d;
     // $workingdayssalary=$countofdays*$onedaysalary;
     $dt1 = strtotime($date);
     $dt2 = date("l", $dt1);
     $dt3 = strtolower($dt2);
     if($dt3 == "friday"){
     $amounttobeentered=$salary->salary/$countofdays*1.5;
     }
     else{
        $amounttobeentered=($salary->salary/$countofdays);
     }
     $this->expensledger('salary101',5,"expense",null,$this->roundFigure($amounttobeentered),10,$employee,$date);
     $this->liabilityledger('liability_employee_'.$employee,5,"liabilities",$this->roundFigure($amounttobeentered),null,10,$employee,$date);
     // echo 'Whole Days Salary '.$employee.'  '.$salary->salary."<br>";

     // echo 'Working Days Salary'.$employee.'  '.$workingdayssalary."<br>";
    }

   

    public function storestitchunitledgerfromattendenceform($employee,$date){
     $salary = Employee::where('id',$employee)->where('employees.available',1)->first();
    //  $countofdays=$this->countDays(2018,date('m',strtotime($date)), array(7, 5));
     $countofdays=date('t',strtotime($date));
     $amounttobeentered=($salary->salary/$countofdays);
     
     $this->salaryamount =$this->salaryamount+$amounttobeentered;

     $this->liabilityledger('liability_employee_'.$employee,5,"liabilities",null,$this->roundFigure($amounttobeentered),10,$employee,$date);
    }
    
    //storing credit sale ladger 
    public function credit_sale_ladger($account_id,$debit_ammount,$refrenceid,$transectiontype,$date){

        $this->assetledger($account_id,1,"assets",$debit_ammount,null,11,$refrenceid,$date);
    }

     public function sale_ledger($total,$refrenceid,$date){
        $this->incomeledger(10101,4,"income",$total,null,11,$refrenceid,$date);
    }


    //storing credit sale ladger 
    public function credit_sale_ladger_return($account_id,$credit_ammount,$refrenceid,$transectiontype,$date){

        $this->assetledger($account_id,1,"assets",null,$credit_ammount,$transectiontype,$refrenceid,$date);
    }

     public function sale_ledger_return($total,$refrenceid,$date){
        $this->incomeledger(10101,4,"income",null,$total,2,$refrenceid,$date);
    }


    public function returnsaleview(){
        $customers=Customer::all();
        $farmers  =Farmer::all(); 
        $chartofaccounts=DB::table('cprelations')->select('cprelations.*','chartofaccounts.account_type')->leftjoin('chartofaccounts','chartofaccounts.coa_id','cprelations.acc_id')->orderByRaw("FIELD(def ,1) DESC")->get();

        return view('employees/returnsale',['customers'=>$customers,'farmers'=>$farmers ,'chartofaccounts'=>$chartofaccounts]);
    }

    public function showadvanceform(){
        //chart of accounts from cprelation table 
        $chartofaccounts=DB::table('cprelations')->select('cprelations.*','chartofaccounts.account_type')->leftjoin('chartofaccounts','chartofaccounts.coa_id','cprelations.acc_id')->orderByRaw("FIELD(def ,1) DESC")->get();
        $employees=Employee::get();
        return view('employees/advance',compact('employees','chartofaccounts'));
    }

    public function storeadvance(Request $request){
        $advance=new Employeeadvance;
         $advance->employee_id=$request->emp;
         $advance->date=$request->date." ".date('H:i:s');
         $advance->amount=$request->advance;
         $advance->coa=$request->coa;
         if($advance->save()){
            $refrenceid=Employeeadvance::orderby('id','desc')->first();
            $this->storadvanceledger('expense_employee_'.$request->emp,5,$request->advance,$refrenceid->id,10,$request->date,$request->coa);
            $request->session()->flash('message.level','success');
            $request->session()->flash('message.content','Employee Advance Saved!');
            return redirect('employee/advance');
         }

    }
    public function storadvanceledger($employee_id,$acc_id,$advance,$refrenceid,$transectiontype,$date,$fromaccount){

        $this->assetledger($fromaccount,1,"assets",Null,$advance,$transectiontype,$refrenceid,$date);
        $this->expensledger($employee_id,5,"expense",$advance,null,$transectiontype,$refrenceid,$date);
    }
    public function employeepayslip(){
        $countofdays=$this->countDays(date('y'),date('m'), array([]));
       // $countofdays=date('t');
        $employees=Employee::get();
        return view('employees/payslip',compact('employees','countofdays'));
    }

    function countDays($year, $month, $ignore) {
    $count = 0;
    $counter = mktime(0, 0, 0, $month, 1, $year);
        while (date("n", $counter) == $month) {
            if (in_array(date("w", $counter), $ignore) == false) {
                $count++;
            }
            $counter = strtotime("+1 day", $counter);
        }
        return $count;
    }


    public function employeepaydetails(Request $request){
        $data = '';
        $countofdays=$this->countDays(date('y'),$request->month, array([]));
        $employees =Employee::select('name','salary','id')->get();
        $recordCount = count($employees);
        $count =1;
        $data .='[';
        foreach ($employees as $value) {
        $data .='{"name":"'.$value->name.'","salary":'.$value->salary.',"id":'.$value->id.',';

        $bonuses=DB::table('bonuses')->whereRaw('MONTH(bonuses.created_at) = ?',[$request->month])->where('emp',$value->id)->sum('bonus');
            
        $data .='"bonus":'.$bonuses.',';

        $presents=Attendence::whereRaw('MONTH(attendences.date) = ?',[$request->month])->where('empid',$value->id)->sum('attendence');

        $data .='"attendence":'.$presents.',';

        $overtimes=Attendence::whereRaw('MONTH(attendences.date) = ?',[$request->month])->where('empid',$value->id)->sum('overtime');

        $data .='"overtime":'.$overtimes.',';
        
        $advance =DB::table('payrolladvances')->whereRaw('MONTH(payrolladvances.created_at) = ?',[$request->month])->where('employee_id',$value->id)->sum('amount');

        $data .='"advances":'.$advance.'';
        

        $liability = Ledger::where('account_id','liability_employee_'.$value->id)->orderby('date','DESC')->first();
        //return $liability;
        if($liability != null)
            $data .=',"liability":'.$liability->balance.'';
        else
        $data .=',"liability":0';
        
        $data .="}";
        if($count < $recordCount)
            $data .=",";
        $count++;
        
        }
        $data .=']';
        echo $data;
        // echo json_encode(array($countofdays,$employees,$bonuses,$presents,$advance,$duesalary));
        
    }

   

    public function getcustomerbalance(Request $request){

         $invoices = Sale::where('sales.customer' , $request->customer_id)->get();
        echo json_encode($invoices);
    }

     public function stich_invoice(Request $request){

        $product  = Saleproduct::leftjoin('products' , 'products.product_id' ,'=' ,'saleproducts.description')->where('saleproducts.inv_id' , $request->sale_invoice_number)->get();

        echo json_encode($product);
    }

    public function stich_items(Request $request){

        $product  = Saleproduct::leftjoin('products' , 'products.product_id' ,'=' ,'saleproducts.description')->where('saleproducts.description' , $request->sale_invoice_number)->where('saleproducts.inv_id' , $request->invoice)->get();

        echo json_encode($product);
    }

    public function roundFigure($value) {
       return ceil($value);
    }

    public function Addinventory($pid,$biil_id,$sup_id,$cost_price,$qty,$date){
        $inventory=new Inventory;
        $inventory->inv_product_id=$pid;
        $inventory->inv_bill_id=$biil_id;
        $inventory->inv_supplier_id=$sup_id;
        $inventory->inv_cost_price=$cost_price;
        $inventory->inv_qty=$qty;
        $inventory->inv_purchased_qty=$qty;
        $inventory->inv_bill_date=$date;
        $inventory->save();
    }


    public function cost_sale_ledger($total,$refrenceid,$date,$datebit){

        
        $this->expensledger(10102,5,"expense",null,$total,2,$refrenceid,$date);
        // if($datebit == 1){
        // $this->expensledger(10102,5,"expense",$total,null,2,$refrenceid,$date);
        // }
        // else if($datebit == 0){
        // $this->current_date_expensledger(10102,5,"expense",$total,null,2,$refrenceid,$date);
        // }
    }

}
