<?php

namespace App\Http\Controllers;

use App\Farmerpurchase_products;
use Illuminate\Http\Request;

class Farmerpurchase_products_controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Farmerpurchase_products  $farmerpurchase_products
     * @return \Illuminate\Http\Response
     */
    public function show(Farmerpurchase_products $farmerpurchase_products)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Farmerpurchase_products  $farmerpurchase_products
     * @return \Illuminate\Http\Response
     */
    public function edit(Farmerpurchase_products $farmerpurchase_products)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Farmerpurchase_products  $farmerpurchase_products
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Farmerpurchase_products $farmerpurchase_products)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Farmerpurchase_products  $farmerpurchase_products
     * @return \Illuminate\Http\Response
     */
    public function destroy(Farmerpurchase_products $farmerpurchase_products)
    {
        //
    }
}
