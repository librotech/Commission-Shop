<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Sale;
use App\Saleproduct;
class PrintController extends Controller
{
	public function abc(){
		// header('location','alert:id=3');
		
		// echo "working";
	}
     public function printsale($inv_id){
        $data="";
        $count = 1;
        $a= Sale::select('sales.id','sales.date','sales.date','sales.subtotal','sales.cashpaid','sales.duebalance','customers.customer_name')->leftjoin('customers','customers.customer_id','=','sales.customer')->where('sales.id',$inv_id)->first();
            
        $data='[{"details":{"id":'.$a->id.',"subtotal":'.$a->subtotal.',"cashpaid":'.$a->subtotal.',"duebalance":'.$a->subtotal.',"customer_name":"'.$a->customer_name.'"},"products":[';
        

        $products =Saleproduct::select('saleproducts.sale_price','saleproducts.qty','saleproducts.inlinetotal','saleproducts.description')->where('inv_id',$inv_id)->get();
        $productcount=Saleproduct::select('saleproducts.sale_price','saleproducts.qty','saleproducts.inlinetotal','saleproducts.description')->where('inv_id',$inv_id)->count();
        foreach ($products as $product) {
            # code...
            $data .='{"sale_price":'.$product->sale_price.',"qty":'.$product->qty.',"inlinetotal":'.$product->inlinetotal.',"description":"'.$product->description.'"}';
            if($count < $productcount){
                $data .=",";
            }
            $count++;
        }
            
        $data .="]}]";
       echo $data;
        // print_r($request);
        // $stringarray="";
        // // $stringarray .= "['invoice': '".$request->invno."', 'Dated': '".$request->invdate."','Customer': '".$request->invcustomer."', 'Total': '".$request->total."'],";
        // for($i=0;$i < count($request->product); $i++){
        //     $stringarray .='["product" =>"'.$request->description[$i].'","qty"=>'.$request->qty[$i].',"price"=>'.$request->price[$i].'],';
            
        // }
        // $stringarray =substr_replace($stringarray, '', -1);
        // header("Content-type: application/json");
        // $data=json_encode(array($stringarray));
        // return view('sale.print',compact('data'));
    }

    
}
