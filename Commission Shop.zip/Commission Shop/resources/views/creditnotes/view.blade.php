@extends('layouts.master')

@section('title', 'Accounts System-Return Sale')

@section('content')
 <ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('creditnotes/add') }}">Return Sale</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active"  >All Sales Return</a>
      </li>
      
    </ul>
<br>
    <h3>All Sales Return</h3> <a href="{{ url('creditnotes/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Return Sale</a>
    <hr>
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Creditnote Id</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
        </tr>
        </thead>
        <tbody>
        @foreach($creditnotes as $creditnote)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $creditnote->id }}</td>
                <td>{{ $creditnote->customer_name }}</td>
                <td>{{ $creditnote->total }}</td>
                <td>{{ $creditnote->name }}</td>
                <td>{{ date('d-m-Y', strtotime($creditnote->created_at))}}</td>
                <td><a href="{{ url('creditnote/void/'.$creditnote->id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This Purchase creditnote?');">Void</a></td>
            </tr>
            
        @endforeach
     </tbody>
    <tfoot>
            <tr>
             <th>SNo.</th>
            <th>Creditnote Id</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            </tr>
        </tfoot>
    </table>
@stop
