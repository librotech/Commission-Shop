<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>@yield('title')</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="{{ url('/assets/css/bootstrap.min.css') }}" media="screen">
  <link rel="stylesheet" href="{{ url('/assets/css/jquery-ui.css') }}" media="screen">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" media="screen">
  <link rel="stylesheet" href="{{ url('/assets/css/dataTables.bootstrap4.min.css') }}" media="screen">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" media="screen">
  
  <script src="{{ url('/assets/js/jquery.js') }}"></script>
  <script src="{{ url('/assets/js/jquery-ui.js') }}"></script>
   
    
	<script>
    
  $( function() {
    $( "#datepicker" ).datepicker({ dateFormat: "yy-mm-dd" <?php if(isset($fy)){
      echo',minDate: new Date('.$fy.')' ;} ?> });
  } );
  
   $( function() {
    $( "#datepicker2" ).datepicker({ dateFormat: "yy-mm-dd" <?php if(isset($fy)){
      echo',minDate: new Date('.$fy.')' ;} ?> });
  } );
  $(window).on('load',function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
  </script>
  <style type="text/css">

  body a,h1,h2,h3,h4,h5,h6,p,b,span,label,td,th,button,input,canvas {
      font-family: Arial, Helvetica, sans-serif;
    }
  .card-header{
    height:42px;
    padding:10px;
    padding-left:15px;
    background:#385793;
    font-size:14px;
  }
  /* unvisited link */
  body a:link  {
      color: #EAEEF3;
  }

  /* visited link */
  body a:visited {
      color: #EAEEF3;
  }

  /* mouse over link */
  body a:hover  {
      color: #B5BAC4;
  }

  /* selected link */
  body a:active  {
      color: #EAEEF3;
  }

 .dropdown-toggle{
    color:white;
  }
   .dropdown-menu a:link{
    color: #343a40;
  }
   .dropdown-menu a:visited{
    color: #343a40;
  }
   .dropdown-menu a:hover{
    color: #B5BAC4;
  }
   .dropdown-menu a:active{
    color: #343a40;
  }
  table tr td a:link {
    color:blue;
  }
  table tr td a:visited {
    color:blue;
  }
  table tr td a:hover {
    color: #B5BAC4;
  }
  table tr td a:active {
    color:blue;
  }
  ul li .nav-link{
    background:#385793;
    border:1px solid white !important;
  }
  nav a{
    color:white;
  }
  .btn , .dt-button{
    background:#385793 !important;
    color:white !important;
  }
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  /*width: 100%;*/
  height: 100%;
  z-index: 9999;
  opacity: 0.7;
  text-align:center;
  /*background: url('https://support.sonymobile.com/app/themes/SonyMobileSupportV2/dist/images/balls.gif') center no-repeat #fff;*/
  background: url('{{ url('assets/images/loading.gif')  }}') center no-repeat #fff;
}
</style>
</head>
<body>
    
<!-- <nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="{{ url('/') }}">Navbar</a>
  <a href="nav navbar-right">Credit Notes</a>
  <a href="nav navbar-right">Debit Notes</a>
</nav> -->
<nav class="navbar navbar-expand-sm" style="background:#385793 !important;">
  
  <a class="navbar-brand" href="{{ url('/home') }}" style="color:white;">LIBRO ERP</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" ></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" >
      
    </ul>

    <ul class="nav navbar-nav navbar-right">
      @if(Auth::user()->role != 3)
      <!--<li class="nav-item dropdown">-->
      <!--  <i class="fas fa-file" style="color:white;"></i>&nbsp<a  href="{{ url('report/view') }} ">Reports</a>&nbsp&nbsp-->
      <!--</li>-->
       <li class="nav-item dropdown">
        <i class="fas fa-file" style="color:white;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Reports <span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
         <a  class="dropdown-item" href="{{ url('ledger/show') }}">Ledger</a>
      <a  class="dropdown-item" href="{{ url('ledgercoareport') }}">Ledger Report by Chart Accounts</a>
      @if(Auth::user()->role == 1)
      <a  class="dropdown-item" href="{{ url('profitandlossreport') }}">Profit And Loss Report</a>
      <a  class="dropdown-item" href="{{ url('balancesheetreport') }}">Balance Sheet Report</a>
      <a  class="dropdown-item" href="{{ url('trialbalance') }}">Trial Balance Report</a>
      <a  class="dropdown-item" href="{{ url('purchase_report') }}">Purchases Reports</a>
      <a  class="dropdown-item" href="{{ url('sales_report') }}">Sales Reports</a>
      <a  class="dropdown-item" href="{{ url('stock_report') }}">Stocks Reports</a>
      <a  class="dropdown-item" href="{{ url('dailyexpenses') }}">Expense Reports</a>
      @endif
    	
    
         
             </div>
      </li>
      @endif
      &nbsp &nbsp &nbsp
        <li class="nav-item dropdown">
        <i class="fas fa-shopping-basket" style="color:white;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Product <span class="caret"></span></a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="{{ url('product/add') }}" class="dropdown-item">Add New</a>
          <a href="{{ url('product/show') }}" class="dropdown-item">View</a>
        </div>
      </li> 
      &nbsp &nbsp &nbsp
      <li class="nav-item dropdown">
        <i class="fas fa-parachute-box" style="color:white;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Supplier <span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="{{ url('supplier/add') }}" class="dropdown-item">Add New</a>
          <a href="{{ url('supplier/show') }}" class="dropdown-item">View</a>
        </div>
      </li>
      &nbsp &nbsp &nbsp
      <li class="nav-item dropdown">
        <i class="fas fa-parachute-box" style="color:#EAEEF3;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Farmer<span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="{{ url('farmer/add') }}" class="dropdown-item">Add New</a>
          <a href="{{ url('farmer/show') }}" class="dropdown-item">View</a>
        </div>
      </li>
      &nbsp &nbsp &nbsp
      <li class="nav-item dropdown">
        <i class="fas fa-people-carry" style="color:white;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Customer <span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="{{ url('customer/add') }}" class="dropdown-item">Add New</a>
          <a href="{{ url('customer/show') }}" class="dropdown-item">View</a>
        </div>
      </li>
      &nbsp &nbsp &nbsp
      <li class="nav-item dropdown">
        <i class="fas fa-people-carry" style="color:white;"></i>&nbsp<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Employees <span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a href="{{ url('employee/add') }}" class="dropdown-item">Add New</a>
          <a href="{{ url('employee/view') }}" class="dropdown-item">View</a>
          <a href="{{ url('employee/payslip') }}" class="dropdown-item">Pay Slip</a>
          <a href="{{ url('payroll/add') }}" class="dropdown-item">Payroll</a> 
        </div>
      </li>
      &nbsp &nbsp &nbsp
      <li class="nav-item">
        <i class="fas fa-store" style="color:white;"></i>&nbsp<a href="{{ url('inventory/show') }}">Inventories</a> 
        </li> 
      &nbsp &nbsp &nbsp
      <!-- <li class="nav-item ">
        <i class="fas fa-store" style="color:white;"></i>&nbsp<a href="{{ url('notification') }}">Notifications</a> </li> -->
      &nbsp &nbsp &nbsp
      <li class="nav-item dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Hi! {{ ucfirst(Auth::user()->name) }} <span class="caret"></span>
                                </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown" style="margin-top:10px;">
          @if(Auth::user()->role != 3)
          <div>&nbsp&nbsp<a href="{{ url('settings') }}">Settings</a></div>
          @endif
         <div>&nbsp&nbsp<a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();" style="color:grey;">Logout</a></div>
         <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
          {{ csrf_field() }}
         </form>
         
         
        </div>
      </li>
       <!-- Authentication Links -->
      </ul>
  </div>
</nav>
