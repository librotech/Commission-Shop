@extends('layouts.master')

@section('title', 'Accounts System-Cash Paid')


@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
          <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link active">Cash Paid</a>
    </li>
</ul><br>
    <h3>Cash Paid</h3>
    <!-- <a href="{{ url('purchase/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View purchases</a> -->
    <hr>
    <p class="alert alert-danger error-message" style="display:none;"></p>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('purchase/cashpaid') }}" id="myForm" method="post">

    	<div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Party Name</label>
                <input class="form-control" required="required" name="supplier"  id="supplier" autocomplete="off" list="parties" placeholder="Select party">
                <datalist id="parties">
                    <option value="">Select</option>
                    @foreach($suppliers as $supplier)
                        <option value="supplier_{{ $supplier->supplier_id }}">{{ $supplier->supplier_name }}</option>
                    @endforeach
                    @foreach($assets as $asset)
                        <option value="{{ $asset->coa_id }}">{{ $asset->coa_title}}</option>
                    @endforeach
                    @foreach($employees as $employee )
                        <option value="liability_employee_{{ $employee->id }}">{{ $employee->name }}</option>
                    @endforeach
                    @foreach($expenseaccounts as $expenseaccount)
                     <option value="{{ $expenseaccount->coa_id }}">{{ $expenseaccount->coa_title }}</option>
                    @endforeach
                </datalist>
            </div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Supplier balance</label>
    			<input type="text"  readonly readonly="readonly"  name="sbal" class="form-control" id="sbal">
                <input type="hidden" name="acctype" id="actype">
                <input type="hidden" id="accid" name="accid">
    		</div>
    	</div>
    	<div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text"  readonly id="datepicker"  style="background:white !important;" autocomplete="off" name="date" class="form-control date" value="{{ date('20y-m-d') }}" placeholder="Enter Date of Bill">
            </div>
        </div>
        

    	</div>
        <div class="row">
            <div class="col-md-3">
                <label>Account</label>
                <select class="form-control" name="coa" id="coa" required="required">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <label>Cash Available</label>
                <input type="number" readonly="readonly" name="cash_available" required="required" id="cash_available" class="form-control">
                </div>
            </div>
        <div class="col-md-3">
                <div class="form-group">
                    <label>Cash Paid</label>
                    <input type="number" placeholder="please enter advance amount" required="required" id="cash_paid" name="cash_paid" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" class="form-control">
                </div>
            </div>
             <div class="col-md-3"></div>
             <div class="col-md-3"><br><button id="save_purchase" class="btn btn-block btn-success">Save</button></div>
            
        </div>
        {{ csrf_field() }}
    </form>

@stop
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
$(document).on('keyup','#cash_paid',function(){
    var cashpaid = $(this).val();
    var cash_available=$('#cash_available').val();
    if(parseInt(cashpaid) > parseInt(cash_available)){
        $('#save_purchase').hide();
    }
    else if(parseInt(cashpaid) < parseInt(cash_available)){
        $('#save_purchase').show();
    }
})

$(document).ready(function(){
    coa();
    function coa(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();

     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#cash_available').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#cash_available').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    }
});
$(document).on('change','#supplier',function(){
    var _token = $('input[name="_token"]').val();
    var supplier =$(this).val();
    if(supplier == ""){
    $('#sbal').val('');
     $('#actype').val('');
     $('#accid').val('');}
    $.ajax({
            type:'POST',
            url:'{{ url("purchase/getsupplierbalance") }}',
            data:{supplier:supplier,_token:_token},
            dataType:'json',
            success:function(data){
                if(data[0] != "null"){
                     $('#sbal').val(data[0]);
                     $('#actype').val(data[1]);
                     $('#accid').val(data[2]);
                     $('#save_purchase').show();
                }
                else{
                    $('#sbal').val(data[0]);
                     $('#actype').val(data[1]);
                     $('#accid').val(data[2]);
                    $('#save_purchase').hide();
                }
            }
        });
});
function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>