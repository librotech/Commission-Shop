@extends('layouts.master')

@section('title', 'Accounts System-Purchase')


@section('content')
    <ul class="nav nav-tabs">
        <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('farmerpurchase/add') }}">New  Purchase</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active"  >All Purchases Receipts</a>
      </li>
      
    </ul>
<br>
    <h3>All Farmer Purchase Receipts</h3> <a href="{{ url('farmerpurchase/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">New Purchase</a>
    <hr>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Bill No</th>
            <th>Farmer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>View</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
        </tr>
        </thead>
        <tbody>
        @foreach($bills as $bill)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $bill->bill_id }}</td>
                <td>{{ $bill->farmers_name }}</td>
                <td>{{ $bill->total_ammount }}</td>
                <td>{{ $bill->name }}</td>
                <td>{{ date('d-m-Y', strtotime($bill->created_at))}}</td>
                <td><a href="{{ url('farmerpurchase/void/'.$bill->bill_id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This purchase Bill?');">Void</a></td>
                <td><a href="{{ url('farmerpurchase/show/'.$bill->bill_id)}}" class="btn btn-success btn-sm">View</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('farmerpurchase/delete/'.$bill->bill_id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            
        @endforeach
        </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Bill No</th>
            <th>Farmer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>View</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>
    
@stop
