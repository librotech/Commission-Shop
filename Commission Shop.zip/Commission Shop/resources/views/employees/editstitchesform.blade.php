@extends('layouts.master')
@section('title', 'Accounts System-Stitching Unit')
@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Edit Stiches Form</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/stichesform') }}">Add Stitches</a>
      </li>
      
    </ul>
<br>
<div class="col-md-12">
<h3>Update Stiches</h3>
<hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
          <form class="form-horizontal" method="POST" action="{{ url('employee/updatestitch') }}">
          {{ csrf_field() }}
          <div class="row">
          <div class="col-md-3 ">
           <div class="form-group">
              <label for="email">Date</label>
              <input  type="text" class="form-control date" readonly="" id="datepicker" name="date"  value="{{ '20'.date('y-m-d') }}" required>
           </div>
          </div>

          <div class="col-md-12"><hr></div>
          <table class="table table-stripped table-responsive">
            <thead>
              <tr>
                <th>Machin</th>
                <th>No Of Stitches</th>
                <th>Employee1</th>
                <th>Employee2</th>
                <th>Employee3</th>
                <th>created at</th>
              </tr>
            </thead>
            <tbody id="data">
             
            </tbody>
            <tfoot>
              <tr>
                <th>Machin</th>
                <th>No Of Stitches</th>
                <th>Employee1</th>
                <th>Employee2</th>
                <th>Employee3</th>
                <th>created at</th>
              </tr>
            </tfoot>
          </table>
          <div class="col-md-12 ">
          <div class="form-group">
              
                  <button type="submit" class="btn btn-success">
                     Update
                  </button>
              </div>
          </div>
                    </form>
                </div>
            </div>
        </div>
   <p id="duplicate_employee" class="duplicate"></p>
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function(){

  //alert($('.date').val());
$(document).on('change','.date',function(){
       var date = $(this).val();
       //alert(date);
       var _token = $('input[name="_token"]').val();
       $.ajax({
         type: 'POST',
         url: '{{ url("employee/employeestitches") }}',
         data: { date:date,_token:_token },
         dataType:'json',
         success: function(data){
          //alert(data);
             var count=1;
                var row="";
                 $.each(data, function (index, obj) {

                     row += "<tr><td><input type='hidden' readonly value="+ obj.sid +" name='rec_id[]' class='form-control' data-id="+count+"><input type='text' readonly value="+ obj.machine +" name='machin[]' class='form-control' data-id="+count+"></td><td><input type='number' value="+obj.stiches+" name='stitch[]' class='form-control' /></td><td><input type='text' readonly value="+obj.emp1name+" name='name' class='form-control' /><td><input type='text' readonly value="+obj.emp2name+" name='name' class='form-control' /><td><input type='text' readonly value="+obj.emp3name+" name='name' class='form-control' /></td><td>"+obj.created_at+"</td></tr>";

                   count++;
                });
                $('#data').html(row);

         }
      });
});
})
function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>