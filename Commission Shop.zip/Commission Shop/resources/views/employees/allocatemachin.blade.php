@extends('layouts.master')

@section('title', 'Accounts System-Employee')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Alot Machine</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('employee/add') }}">Add New Employee</a>
  </li>
  
</ul><br>
    <h3>Alot Machine</h3> 
    <div class="row"><div class="col-md-3"><select id="shift" class="form-control"><option value="">Select</option><option value="day">Day</option><option value="night">Night</option></select></div>
    <div class="col-md-3"><input class="form-control" type="text" readonly="" value="<?php echo '20'.date('y-m-d'); ?>" id="datepicker"></div></div>
    <hr>

   <table class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Machine No</th>
        </tr>
        </thead>
    <tbody id='result'>
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Employee Id</th>
            <th>Employee Name</th>
            <th>Machine No</th>
            </tr>
    </tfoot>
    </table>
    <button type="button" class="btn btn-info" id="save">save</button>    
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).on('change', '#shift','#datepicker', function(){
    var _token = $('input[name="_token"]').val();
    var shift=this.value;
    var date=$('#datepicker').val();
    $.ajax({
         type: 'POST',
         url: '{{ url("employee/showmachine") }}',
         data: { shift:shift,_token:_token },
         success: function(data){
                var count=1;
                var row="";
                 $.each(data, function (index, obj) {
                    row += "<tr><td>"+count+"</td><td><input type='text' readonly value="+ obj.id +" class='form-control empid' data-id="+count+"></td><td>"+obj.name+"</td><td><input type='text' value="+ obj.machineno +" required class='form-control machin"+count+"'></td></tr>";

                   count++;
                });
                $('#result').html(row);
         }
      });
});

$(document).on('click','#save',function(){
    var _token = $('input[name="_token"]').val();
    var attendence=0;
    var message="";
    $('.empid').each(function(i,ob){
        var empid=$(this).val();
        var empdataid=$(this).attr('data-id');
        var machine=$('.machin'+empdataid).val();
        var date=$('#datepicker').val();
        if($('input.attend'+empdataid).is(':checked')){
           attendence=1;
        }

        $.ajax({
         type: 'POST',
         url: '{{ url("employee/savemachin") }}',
         data: { empid:empid,machine:machine,date:date,_token:_token },
         success: function(data){
         }
        });

    })
    alert('Machine Aloted');
});

</script>