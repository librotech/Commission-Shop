@extends('layouts.master')
@section('title', 'Accounts System-Employee Payslip')
@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Employee Pay Slip</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/view') }}">All Employees</a>
      </li>
      
    </ul>
<br>
<div class="col-md-12">
<h3>Employee Pay Slip</h3>
<hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <h5>Total Days This Moth: <span class="text text-warning countofdays">{{ $countofdays }}</span></h5>
     <hr>
    <!--<form class="form-horizontal" method="POST" action="{{ url('employee/storeadvance') }}">-->
    <!--            {{ csrf_field() }}-->

    <!--            <div class="row">-->
    <!--            <div class="col-md-3">-->
    <!--               <div class="form-group">-->
    <!--                <label for="Role">Employees</label>-->
    <!--                    <select id="emp"  class="form-control" name="emp" required>-->
    <!--                        <option value="">Select</option>-->
    <!--                        @foreach($employees as $employee)-->
    <!--                        <option value="{{ $employee->id }}">{{ $employee->name }}</option>-->
    <!--                        @endforeach-->
    <!--                    </select>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 ">-->
    <!--             <div class="form-group">-->
    <!--                <label for="textbox">Working Days</label>-->
    <!--                <input  type="text" class="form-control" readonly="" id="wdays" name="wdays"  required>-->
    <!--              </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 ">-->
    <!--             <div class="form-group">-->
    <!--                <label for="textbox">Workingdays pay</label>-->
    <!--                <input id="wdpay" type="text" class="form-control" name="advance" readonly="" value="{{ old('stich') }}" required>-->
    <!--              </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3"><br><br>-->
                 
    <!--            </div>-->
    <!--            <div class="col-md-3 ">-->
    <!--             <div class="form-group">-->
    <!--                <label for="textbox">Overtime Days</label>-->
    <!--                <input  type="text" class="form-control" readonly="" id="otdays" name="wdays"  required>-->
    <!--              </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-3 ">-->
    <!--             <div class="form-group">-->
    <!--                <label for="textbox">pay</label>-->
    <!--                <input id="otpay" type="text" class="form-control" name="advance" readonly="" value="{{ old('stich') }}" required>-->
    <!--              </div>-->
    <!--            </div>-->
    <!--            <div class="col-md-12 ">-->
    <!--            <div class="form-group">-->
                    
    <!--                    <button type="submit" class="btn btn-success">-->
    <!--                       Save-->
    <!--                    </button>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--              </form>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <input type="text" class="form-control month"  list="months" placeholder="Select Month">
    <datalist id="months">
            <option selected value='1'>Janaury</option>
            <option value='2'>February</option>
            <option value='3'>March</option>
            <option value='4'>April</option>
            <option value='5'>May</option>
            <option value='6'>June</option>
            <option value='7'>July</option>
            <option value='8'>August</option>
            <option value='9'>September</option>
            <option value='10'>October</option>
            <option value='11'>November</option>
            <option value='12'>December</option>
    </datalist>
    <hr>
     <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Name.</th>
            <th>Salary</th>
            <th>Due Salary</th>
            <th>Advance</th>
            <th>Bonus</th>
            <th>Presents</th>
            <th>Absents</th>
            <th>Over Times</th>
        </tr>
        </thead>
        <tbody id="cashsale">
            
        </tbody>
    <tfoot>
            <tr>
            <th>Name.</th>
            <th>Salary</th>
            <th>Due Salary</th>
            <th>Advance</th>
            <th>Bonus</th>
            <th>Presents</th>
            <th>Absents</th>
            <th>Over Times</th>
            </tr>
        </tfoot>
        
    </table>
   
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).on('change','.month', function(){

  var _token = $('input[name="_token"]').val();
  var month=this.value;
   var currentMonthDays =new Date(2019, month, 0).getDate();
  var table = $('#example').DataTable();
        table.clear().draw();
    $.ajax({
         type: 'POST',
         url: '{{ url("employee/employeepaydetails") }}',
         data: { month:month,_token:_token },
         success: function(data){
            console.log(data,"data");
             var name ="";
             var salary=0;
             var liability=0;
             var advance=0;
             var bonus =0;
             var presents=0;
             var numberOfDaysThisMonth =0;
             var overTime=0; 
             var row ="";
             $.each(JSON.parse(data),function(i,obj){

                // row +="<tr>";
                // row +="<td>"+obj.name+"</td>";
                // row +="<td>"+obj.salary+"</td>";
                // row +="<td>"+obj.liability+"</td>";
                // row +="<td>"+obj.advances+"</td>";
                // row +="<td>"+obj.bonus+"</td>";
                // row +="<td>"+obj.attendence+"</td>";
                // row +="<td>"+(parseInt(31)-parseInt(obj.attendence))+"</td>";
                // row +="<td>"+obj.overTime+"</td>";
                // row +="</tr>";
               
                table.row.add([obj.name,obj.salary,obj.liability,obj.advances,obj.bonus,obj.attendence,parseInt(currentMonthDays)-parseInt(obj.attendence),obj.overtime]).draw();
             });
              // $('#cashsale').append(row);
             $('.countofdays').html(currentMonthDays);
         }
      });
});
</script>