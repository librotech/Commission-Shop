@extends('layouts.master')
@section('title', 'Accounts System-Stitching Unit')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('stitchinv/view') }}">View Sales</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">New Sale</a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link" href="{{ url('employee/view') }}">All Employees</a>
      </li> -->
      
    </ul>
<br>
<div class="row">
    <div class="col-md-6"><h3>New Sale</h3></div>
     <div class="col-md-2"><a href="{{ url('stitchinv/view') }}" class="btn btn-info btn-block " >View Sale</a></div>

     <div class="col-md-2 text-right"><a href="{{ url('sale/add') }}" class="btn btn-info btn-block" >Add Manual Sale</a></div>
     <div class="col-md-2 text-right"><button type="button" id='add_tissue' class="btn btn-block" >Add Tissue </button></div>
    <div class="col-md-12"><hr></div>
</div>
<div class="col-md-12">
@if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form class="form-horizontal" method="POST" action="{{ url('stitching/bill') }}">
    {{ csrf_field() }}
    <input type="hidden" id="checktissue" value="0">
    <div id="add_tissue_form">
        
    </div>
    <div class="row">
        <div class="col-md-2">
        <div class="form-group">
            <label for="name">Invoice</label>  
            @foreach($auto_increment as $ai)
                <input type="number" name="inv_no" value="{{ $ai->AUTO_INCREMENT }}" class="form-control" readonly="readonly" id="inv_id" autofocus>
             @endforeach
           
        </div>
    </div>
    <div class="col-md-3">
        <div class="form-group">
            <label for="email">Customer</label>
            <select id="cus" required=""  class="form-control" name="customer" required>
                @foreach($customers as $customer)
                <option value="{{ $customer->customer_id }}">{{ $customer->customer_name }}</option>
                @endforeach
            </select>
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label for="email">Rate</label>
            <input type="text" value="" readonly="readonly" name="rate" id="rate" class="form-control">
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label for="email">Multilevel Rate</label>
            <input type="text" value="" readonly="readonly" name="multilevel_rate" id="multilevel_rate" class="form-control">
        </div>
    </div>
    <div class="col-md-2">
        <div class="form-group">
            <label for="email">Laser Rate</label>
            <input type="text" value="" readonly="readonly" name="laser_rate" id="laser_rate" class="form-control">
        </div>
    </div>
    <div class="col-md-2">
        <label>Design</label>
        <input name="dsn" id="design" class="form-control" required="required" list='disigns'>
        <datalist id='disigns'>
        <option value="">Select</option> 
        @foreach($designs as $design)
            <option value="{{ $design->designncode }}">{{ $design->designncode }}</option>
        @endforeach

        </datalist>
    </div>
    <div class="col-md-3 col-md-offset-4">
    <div class="form-group">
        <label for="Role">Date</label>
            <input type="text" readonly="" value="<?php echo '20'.date('y-m-d'); ?>" class='form-control' id="date" name="date">
        </div>
    </div>
    <table class="table table-hover order-list">
            <thead>
            <tr>
                <th>Description</th>
                <th>No Of Stitches</th>
                <th>Amount</th>
                <th>Length</th>
                <th>SubTotal</th>
            </tr>
            </thead>
            <tbody id="data">
            </tbody>

    </table>
    <div class="col-md-8"></div>
        <div class="col-md-4">
        <div class="form-group">
        <label for="name">Total</label>  
           <input type="number" required="required" value="0" name="ftotal" class="form-control" readonly  id="ftotal" autofocus> 
        </div>
        </div>
        <div class="col-md-8"></div>
        <div class="col-md-2">
        <div class="form-group">
          <button type="submit" class="btn btn-success btn-block">
                print / Save
                </button>
            </div>
        </div>
        <div class="col-md-2">
        <div class="form-group">
        <button type="button" class="btn btn-success btn-block" id="print">
                    print
                </button>
            </div>
        </div>
        </form>
        </div>
     </div>
    </div>
    <input type="hidden" name="" id="count" value="0">
@endsection
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).on('click','#add_tissue',function(){
    var form='';
    form +='<div class="row">';
    form +='<div class="col-md-3"><div class="form-group"><label>Description</label><input type="text"  name="tissue" value="tissue" tabindex="-1" class="form-control" readonly placeholder="Product Description"></div></div>';
    form +='<div class="col-md-3"><div class="form-group"><label>Sale Price</label><input required="required" type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" id="sale_price"  tabindex="-1"  name="price" class="form-control price s_price1" placeholder="sale Price"></div></div>';
    form +='<div class="col-md-3"><div class="form-group"><label>Length</label><input required="required" type="text" required="required"  onkeypress="return isNumberKey(event,this)" id="qty" name="qty" value="0" class="form-control qty pqty1" placeholder="Product Length"></div></div>';
     form +='<div class="col-md-3"><div class="form-group"><label>Amount</label><input readonly type="text" id="amount" class="form-control"></div></div>';
    form +='<div class="col-md-12"><hr></div>';
    form +='</div>';
    $('#add_tissue_form').html(form);
    $('#checktissue').val('1');
})
$(document).on('change','#qty',function(){

    $('#amount').val(parseInt($('#qty').val())*parseInt($('#sale_price').val()));
    grandtotal();
})
$(document).on('change','#sale_price',function(){
    $('#amount').val(parseInt($('#qty').val())*parseInt($('#sale_price').val()));
    grandtotal();
})

    $(document).on('change','#design',function(){
        calculateDeisgnValues($(this).val());
    });
    function calculateDeisgnValues(design){
        var _token = $('input[name="_token"]').val();
         var design=design;
         var rate=$('#rate').val();
         var multilevel_rate =$('#multilevel_rate').val();
         var laser_rate =$('#laser_rate').val();
         var count = $('#count').val();
         if(design != ""){
            $.ajax({
              type: 'POST',
              url: '{{ url("stitch/designdetail") }}',
              dataType:'json',
              data: { design:design,_token:_token },
              success: function(data){
                var row="";
                var lastcountid=count;
                row +="<tr class='parent"+count+"'><td colspan='6'><input type='text' value="+design+" name='desgin[]' class='form-control' readonly style='background-color:#385793;font-size:20px;color:white !important;'><button type='button' class='btn removeparent' style='float:right;margin-top:-42px;margin-left:-5px;' data-id='"+count+"'>x</button></td></tr>";
                 $.each(data, function (index, obj) {
                    row += "<tr class='row"+count+"'><input type='hidden' value="+design+" name='linkeddesign[]'><td><input type='text' class='form-control' readonly name='description[]' value=" + obj.description + " ></td>";
                row += "<td><input type='text' class='form-control' readonly name='stitch[]' value=" + obj.no_stitch+ " ></td>";
                   if(obj.m_type == 2.77){
                    if(obj.three30_type == 0){
                        if(obj.description == 'Gala' || obj.description == 'Chest'){
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round(((obj.no_stitch/1000)*multilevel_rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                        else{
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round((((obj.no_stitch/1000)*obj.m_type)*multilevel_rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                    }
                    if(obj.three30_type == 1){
                        if(obj.description == 'Gala' || obj.description == 'Chest'){
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round(((obj.no_stitch/1000)*laser_rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                        else{
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round((((obj.no_stitch/1000)*obj.m_type)*laser_rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                    }
                    if(obj.three30_type == 2){
                        if(obj.description == 'Gala' || obj.description == 'Chest'){
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round(((obj.no_stitch/1000)*rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                        else{
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round((((obj.no_stitch/1000)*obj.m_type)*rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                    }
                   }
                    else if(obj.m_type == 2.032){
                        if(obj.description == 'Gala' || obj.description == 'Chest'){
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round(((obj.no_stitch/1000)*rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                        else{
                        row += "<td><input type='text' class='form-control' readonly name='amount[]' value=" +Math.round((((obj.no_stitch/1000)*obj.m_type)*rate)*100)/100 + " id='amount"+count+"'></td>";
                        }
                    }
                 
                row += "<td><input type='text' class='form-control length' data-id="+count+" id='length"+ count +"' name='length[]' required='required'></td><td><input type='text' class='form-control total'  name='inlinetotal[]' id='total"+count+"' readonly ></td><td><button type='button' class='btn btn-danger remove' data-id='"+count+"'>×</button></td></tr>";
                   count++;
                });
                row +='<input type="hidden" value="'+count+'" id="lastid'+lastcountid+'">';
                $('#data').append(row);
                $('#count').val(count);
              }
          });
        }
    }
    $(document).on('change','.length',function(){
        var id=$(this).attr('data-id');
        var length = parseFloat($('#length'+id).val());
        var amount = parseFloat($('#amount'+id).val());
        if(length == '')
            $('#total'+id).val(amount);
        if(amount == '')
            $('#total'+id).val(length);
        else
        $('#total'+id).val(Math.round((length * amount)*100)/100);
        grandtotal();
    })
    $(document).on('click','.remove',function(){
        var id=$(this).attr('data-id');
        $('.row'+id).remove();
        grandtotal();
    });
    $(document).on('click','.removeparent',function(){
        var id=$(this).attr('data-id');
        var lastcountid=$('#lastid'+id).val();
        var startval=id;
        alert(lastcountid);
        $('.parent'+id).remove();

        for(var i=startval;i < lastcountid;i++){
          $('.row'+i).remove();
        }
        grandtotal();
    });
    
function grandtotal(){
    var tissue_ammount =$('#amount').val();
    var checktissue=$('#checktissue').val();
    var total=0;
    $('.total').each(function(i, obj) {
        if($(this).val() != "")
        total +=parseFloat($(this).val());
    });
    if(checktissue == 1)
    $('#ftotal').val(Math.round(total)+parseInt(tissue_ammount));
    if(checktissue == 0)
    $('#ftotal').val(Math.round(total));
}

$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var customerid = $('#cus').val();
    $.ajax({
        url:'{{ url("customer/rate") }}',
        type:'POST',
        data:{ _token:_token,customerid:customerid },
        dataType:'json',
        success:function(response){
           $('#rate').val(response[0]);
           $('#multilevel_rate').val(response[1]);
           $('#laser_rate').val(response[2]);
        }
    })
});

$(document).on('change','#cus',function(){
    var _token = $('input[name="_token"]').val();
    var customerid = $(this).val();
    $.ajax({
        url:'{{ url("customer/rate") }}',
        type:'POST',
        data:{ _token:_token,customerid:customerid },
        dataType:'json',
        success:function(response){
           $('#rate').val(response[0]);
           $('#multilevel_rate').val(response[1]);
           $('#laser_rate').val(response[2]);
        }
    })
})
function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>