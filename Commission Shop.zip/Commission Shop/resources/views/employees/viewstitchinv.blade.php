@extends('layouts.master')

@section('title', 'Accounts System-Sale')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Sales</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('sale/add') }}">New Sale</a>
  </li>

</ul><br>
    <h3>All Sale Recipts</h3> <a href="{{ url('employee/stichingunit') }}" class="btn btn-info" style="float:right;margin-top:-40px;">New Sale</a>
    <hr>
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>view</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
        </tr>
        </thead>
        <tbody>
        @foreach($sales as $sale)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $sale->id }}</td>
                <td>{{ $sale->customer_name }}</td>
                <td>{{ $sale->total }}</td>
                <td>{{ $sale->name }}</td>
                <td>{{ $sale->date }}</td>
                <td><a href="{{ url('sale/void/'.$sale->id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This sale?');">Void</a></td>
                <td><a href="{{ url('sale/show/'.$sale->id)}}" class="btn btn-success btn-sm">view</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('sale/delete/'.$sale->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>view</th>
             @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>

@stop
