@extends('layouts.master')

@section('title', 'Accounts System-All sale')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >View Farmer sale</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('farmersale/add') }}">New Farmer sale</a>
  </li>

</ul><br>
    <h3>All Farmer sale Recipts</h3> <a href="{{ url('farmersale/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">New sale</a>
    <hr>
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Farmer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>view</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
        </tr>
        </thead>
        <tbody>
        @foreach($sales as $sale)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $sale->id }}</td>
                <td>{{ $sale->farmers_name }}</td>
                <td>{{ $sale->subtotal }}</td>
                <td>{{ $sale->name }}</td>
                <td>{{ date('d-m-Y', strtotime($sale->created_at))}}</td>
                <td><a href="{{ url('farmersale/void/'.$sale->id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This sale?');">Void</a></td>
                <td><a href="{{ url('farmersale/show/'.$sale->id)}}" class="btn btn-success btn-sm">view</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('farmersale/delete/'.$sale->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Invoice No</th>
            <th>Customer</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            <th>view</th>
             @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>

@stop
