@extends('layouts.master')

@section('title', 'Accounts System-Cash Recieved')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Sale Return</a>
  </li>
</ul><br>
     <h3>Cash Received</h3>
    <!-- <a href="{{ url('purchase/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View purchases</a> -->
    <hr>
    <p class="alert alert-danger error-message" style="display:none;"></p>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('sale/paymentrecieved') }}" id="myForm" method="post">

        <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Party Name</label>
                <input class="form-control" required="required" name="customer" list="browsers" id="customer" placeholder="Select Party Name">
               <datalist id="browsers">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->coa_id }}">{{ $customer->coa_title }}</option>
                    @endforeach
               </datalist>
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Party Balance</label>
                <input class="form-control" required="required" readonly="readonly" name="partyBalance" id="partyBalance" placeholder="Party Balance">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text"  readonly id="datepicker"  style="background:white !important;" autocomplete="off" name="date" class="form-control date" value="{{ date('20y-m-d') }}" placeholder="Enter Date of Bill">
            </div>
        </div>
        

        </div>
        <div class="row">
            <div class="col-md-3">
                <label>Account</label>
                <select class="form-control" name="coa" id="coa" required="required">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                </select>
            </div>
        <div class="col-md-3">
                <div class="form-group">
                    <label>Cash Received</label>
                    <input type="number" placeholder="please enter advance amount" required="required" id="cash_paid" name="cash_paid" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" class="form-control">
                </div>
            </div>
            <div class="col-md-6"></div>
             <div class="col-md-3"><br><button id="save_purchase" class="btn btn-block btn-success">Save</button></div>
            
        </div>
        {{ csrf_field() }}
    </form>

@stop
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
$(document).on('change','#customer',function(){
    var _token = $('input[name="_token"]').val();
    var customer =$(this).val();

     $.ajax({
            type:'POST',
            url:'{{ url("sale/partybalance") }}',
            data:{customer:customer,_token:_token},
            success:function(data){
                $('#partyBalance').val(data);
                console.log(data);
                if(data == "null")
                    $('#save_purchase').attr('disabled',true)
                else
                    $('#save_purchase').attr('disabled',false)
            }
        });
})
$(document).ready(function(){
    coa();
    function coa(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();

     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#cash_available').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#cash_available').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    }
});

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }
</script>