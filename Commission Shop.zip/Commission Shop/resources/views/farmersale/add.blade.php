@extends('layouts.master')
@section('title', 'Accounts System-Add New Sales')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('farmersale/show') }}">View Sales</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >New Farmer Sales</a>
  </li>
</ul><br>
    <h3>New Farmer Sale</h3>
    <a href="{{ url('farmersale/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Sales</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('farmersale/save') }}" id="myForm" method="post">
        <input type="hidden" name="date_bit" id="date_bit">
        <div id="myDiv">
        <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Bill No</label>
                @foreach($auto_increment as $ai)
                <input type="number" name="txt_inv_no" value="{{ $ai->AUTO_INCREMENT }}" class="form-control"  id="inv_id">
                @endforeach
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text" readonly="readonly" id="datepicker" value="<?php echo "20".date('y-m-d', time()); ?>" style="background:white !important;" name="txt_date" class="form-control">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Farmer id</label>
               <input type="text"  data-id="1" required="required"  name="txt_farmer_id" value="{{ $walkincus->farmers_id }}" class="form-control" list="customers" id="cus">
                    <datalist id="customers">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->farmers_id }}"><b>{{ $customer->farmers_name }}</b></option>
                    @endforeach
                    </datalist>
            </div>
        </div><div class="col-md-3">
            <div class="form-group">
                <label>Farmer name</label>
                <input type="text" readonly="readonly" id="farmers_name" name="txt_farmer_name" class="form-control" placeholder="Enter Farmer Name">
            </div>
        </div>

        </div>
        <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Product</th>
                    <th>Description</th>
                    <th>Bags</th>
                    <th>Kg</th>
                    <th>Sale Price</th>
                    <th>Total Weight</th>
                    <th>Amount</th>
                    <th>Add More</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <input type="text" required="required" data-id="1"  name="txt_product_id1" class="form-control product_id" autocomplete="no" placeholder="Product" list="products" autofocus>
                    <datalist id="products">
                    @foreach($products as $product)
                        <option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>
                    @endforeach
                    </datalist>
                    </td>
                    <td><input type="text"  readonly="readonly" name="txt_product_description1" tabindex="-1" class="form-control pro_des1" placeholder="Product Description"></td>
                    
                    <td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="bags" name="bags1" class="form-control bags bags1" placeholder="Number of Bags">
                
                        <input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="bags_qty" name="bags_qty1" class="form-control bags_qty1 bags_qty" placeholder="Number of Bags">
                    </td>
                    <td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="qty" name="qty1" class="form-control qty qty1" placeholder="Product Quantity"></td>

                    <td><input required="required" type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" id="sale_price" tabindex="-1"  name="price1" class="form-control price s_price1" placeholder="Sale Price">

                        <input required="required" type="hidden" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" id="p_price" tabindex="-1"  name="p_price1" class="form-control p_price p_price1" placeholder="Sale Price">
                    </td>

                    <td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="tqty" name="tqty1" class="form-control tqty tqty1" placeholder="Total Quantity" readonly="readonly"></td>
                    <td><input type="number" id="ammount"  name="linetotal1" class="form-control txt_amount linetotal it1" readonly="readonly"  placeholder="Amount"></td>
                    <td><input type="button" id="addrow" value="Add More" class="btn btn-success"></td>

                </tr>
            </tbody>

        </table>
        <hr>
      
           

        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-3">
                <div class="form-group" style="display:none;" id="coamain">
                  <label><b>Accounts Available</b></label>
                    <select class="form-control" name="coa"  id="coa">
                    @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}</option>
                    @endforeach
                    </select>  
                </div>
                
            </div>
            
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" id="total" name="total" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
            <style type="text/css"> 
            .cmn-toggle {
                    position: absolute;
                    margin-left: -9999px;
                    visibility: hidden;
                  }
                  .cmn-toggle + label {
                    display: block;
                    position: relative;
                    cursor: pointer;
                    outline: none;
                    user-select: none;
                  }
                  input.cmn-toggle-round + label {
                    padding: 2px;
                    width: 120px;
                    height: 40px;
                    background-color: #dddddd;
                    border-radius: 60px;
                  }
                  input.cmn-toggle-round + label:before,
                  input.cmn-toggle-round + label:after {
                    display: block;
                    position: absolute;
                    top: 1px;
                    left: 1px;
                    bottom: 1px;
                    content: "";
                  }
                  input.cmn-toggle-round + label:before {
                    right: 1px;
                    background-color: #f1f1f1;
                    border-radius: 60px;
                    transition: background 0.4s;
                  }
                  input.cmn-toggle-round + label:after {
                    width: 58px;
                    background-color: #fff;
                    border-radius: 100%;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
                    transition: margin 0.4s;
                  }
                  input.cmn-toggle-round:checked + label:before {
                    background-color: #8ce196;
                  }
                  input.cmn-toggle-round:checked + label:after {
                    margin-left: 60px;
                  }</style>
                
            </div>
            <div class="col-md-3">
                <!-- <div class="form-group">
                    <label><b>Discount</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter Discount" id="discount" name="discount" class="form-control">
                </div> -->
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
          <div class="col-md-3">
                <div class="form-group">
                    <label><b>Commission</b></label>
                    <input type="number"     id="commission" name="commission" class="form-control" >
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            
            <!-- <div class="col-md-3"> -->
                <!-- <div class="form-group">
                    <label><b>Previous Balance</b></label>
                <input type="number"  readonly="readonly" name="p_balance" id="p_balance" class="form-control">
                </div> -->
            <!-- </div> -->
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
       <!--  <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>New Balance</b></label>
                    <input type="number" readonly="readonly"   id="n_balance" name="n_balance" class="form-control">
                    <input type="hidden" readonly="readonly"   id="total_amount" name="total_amount" class="form-control">
                </div>
            </div>
        </div> -->
         <!-- <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Credit Sale</b></label>
                    <div class="switch">
                      <input id="cmn-toggle-1" class="cmn-toggle cmn-toggle-round" type="checkbox" name="creditsale">
                      <label for="cmn-toggle-1"></label>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- </div> -->
        <div class="row">
             <div class="col-md-6"></div>
             <div class="col-md-3"><button name="save" class="btn btn-block btn-success">Save</button></div>
            <div class="col-md-3"><button id="save_purchase" name="save" class="btn btn-block btn-success" >Save And Print</button></div>
            <input type="hidden" name="token" id="token">
            
        </div>
        {{ csrf_field() }}
    </form>
@stop
<!-- 
<img src='https://s3-eu-west-1.amazonaws.com/tpd/logos/5a683eff53596d00016d6dac/0x0.png' style='width:200px;height:80px;'> -->
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">


$(document).ready(function () {
    datecheck();
    $('#datepicker').change(function(){
        datecheck();
    });
    function datecheck(){
        var d = new Date();
        var month = d.getMonth()+1;
        var day = d.getDate();
        var output = d.getFullYear() + '-' +
        (month<10 ? '0' : '') + month + '-' +
        (day<10 ? '0' : '') + day;
        var input_date=$('#datepicker').val();
        if(output == input_date){
            $('#date_bit').val("1");
        }
        else{
            $('#date_bit').val("0");
        }
    }
    
    var counter = 1;
    $(".order-list").on("keydown",'.tqty', function (e) {
        if( e.which == 9 || e.which == 13){
             counter++;
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id" placeholder="Product Id" list="products" required autocomplete="no"><datalist id="products" autocomplete="no">@foreach($products as $product)<option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>@endforeach</datalist>';

        cols += '<td><input type="text" readonly="readonly"  name="product_description[]' + counter + '" tabindex="-1" class="form-control pdes pro_des'+counter+'" required/></td>';

        cols += '<td><input type="number"  name="price[]"  tabindex="-1" class="form-control price s_price'+counter+'" required/><input type="hidden"  name="p_price[]"  tabindex="-1" class="form-control p_price p_price'+counter+'" required/></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="bags" name="bags[]" class="form-control bags bags'+counter+'" placeholder="Number of Bags"> <input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="bags_qty" name="bags_qty[]" class="form-control bags_qty bags_qty'+counter+'" placeholder="Number of Bags"></td>';

        cols +='<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="qty" name="qty[]" class="form-control qty qty'+counter+'" placeholder="Product Quantity"></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="tqty" name="tqty[]" class="form-control tqty tqty'+counter+'" placeholder="Total Quantity" readonly="readonly"></td>';

        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal it'+counter+'" required/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
        }
    });
    
    $("table.order-list").on("change", '.bags, .price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });
    $("#addrow").on("click", function () {
        counter++;
        
        var newRow = $("<tr>");
        var cols = "";
        cols += '<td><input type="text" data-id="'+counter+'"  name="txt_product[]" class="form-control product_id" placeholder="Product Id" list="products" required autocomplete="no"><datalist id="products" autocomplete="no">@foreach($products as $product)<option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>@endforeach</datalist>';

        cols += '<td><input type="text" readonly="readonly"  name="product_description[]' + counter + '"  tabindex="-1" class="form-control pdes pro_des'+counter+'" required/></td>';

        cols += '<td><input type="number" tabindex="-1" name="price[]" class="form-control price s_price'+counter+'" required/><input type="hidden"  name="p_price[]"  tabindex="-1" class="form-control p_price p_price'+counter+'" required/></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="bags" name="bags[]" class="form-control bags bags'+counter+'" placeholder="Number of Bags"> <input required="required" type="hidden"  onkeypress="return isNumberKey(event,this)" id="bags_qty" name="bags_qty[]" class="form-control bags_qty bags_qty'+counter+'" placeholder="Number of Bags"></td>';

        cols +='<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="qty" name="qty[]" class="form-control qty qty'+counter+'" placeholder="Product Quantity"></td>';

        cols += '<td><input required="required" type="text"  onkeypress="return isNumberKey(event,this)" id="tqty" name="tqty[]" class="form-control tqty tqty'+counter+'" placeholder="Total Quantity" readonly="readonly"></td>';

        cols += '<td><input type="text" name="linetotal[]" readonly="readonly" class="form-control linetotal it'+counter+'" required/></td><input type="hidden" name="counter[]" value="'+counter+'">';
        cols += '<td><a class="deleteRow btn btn-danger"> x </a></td>';
        newRow.append(cols);
        
        $("table.order-list").append(newRow);
    });
    
    $("table.order-list").on("change", '.bags, .price, .qty', function (event) {
        calculateRow($(this).closest("tr"));
        calculateGrandTotal();
    });
    
    $("table.order-list").on("click", "a.deleteRow", function (event) {
        $(this).closest("tr").remove();
        calculateGrandTotal();
    });

    // $('#cmn-toggle-1').change(function(){
    //     //alert('working');
    //     if($(this).prop('checked')){
    //         $('#save_purchase').css('display','block');
    //     }
    //     else{
    //         $('#save_purchase').css('display','none');
    //     }
    // });
    var count=0;
    $('#save_purchase').on('click',function(){
        count++;
        
    });
    $('#token').val(count);

    var formProcessing = false;

    jQuery("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        if( formProcessing )
            return;

        formProcessing = true;
        jQuery("#myForm").get(0).submit();
        
    });

});
    
function calculateRow(row) {
    
    var bags = +row.find('.bags').val();
    var price = +row.find('.price').val();
    var qty = +row.find('.qty').val();
    var bags_qty = +row.find('.bags_qty').val();
    var totalQty = parseFloat(bags)*parseFloat(bags_qty);
    var total  = (qty + totalQty).toFixed(2);
    // console.log(qty,bags_qty,bags);
    row.find('.tqty').val((bags*65)+qty );
    var total_quantity =+  row.find('.tqty').val();
 // alert(total_quantity);
    row.find('.linetotal').val((price *(total_quantity/40)).toFixed(2));
    
}
//  $(document).on('change','#market_fees',function(){
//     var fees = $("#market_fees").val();
//     calculateGrandTotal();
//         var amount= $("#total").val();
//         if(fees != ""){
//             $("#total").val((parseFloat(amount) + parseFloat(fees)).toFixed(2));
//             $("#total_amount").val( (parseFloat(amount) + parseFloat(fees)).toFixed(2));
//         }
// })


function calculateGrandTotal() {
    var grandTotal = 0;
    var final_ammount = 0;
    
     $("table.order-list").find('.linetotal').each(function () {
         grandTotal += +$(this).val();
                 // $('#cmn-toggle-1').attr("disabled", true);
                $('#save_purchase').css('display','block');
             
     });
    
    $("#total").val(grandTotal.toFixed(2));
    $("#total_amount").val(grandTotal);
     var grandTotal= $("#total").val();
     var previous_bal = $('#p_balance').val();

     $('#n_balance').val(previous_bal - grandTotal);




     $("#discount").keyup(function(){
        var afterdiscount=0;
        var discount=$(this).val();
        if(discount != 0){
           afterdiscount=grandTotal-discount-$("#cash_paid").val();
          // $("#total_amount").val(afterdiscount);
          //     if($("#total_amount").val() == 0 ){
          //       $('#cmn-toggle-1').attr("checked", false);
          //       $('#cmn-toggle-1').attr("disabled", true);
          //       $('#save_purchase').css('display','block');
          //   }
          //  else if($("#total_amount").val() != 0){
          //   $('#cmn-toggle-1').attr("checked", false);
          //   $('#cmn-toggle-1').attr("disabled", false);
          //   $('#save_purchase').css('display','none');    
          //   }
        }
        if(discount == ""){
            $("#total_amount").val(grandTotal-$("#cash_paid").val());
        }
       
    })
    $("#cash_paid").keyup(function(){
        var aftercashpaid=0;
        var cashpaid=$(this).val();
        if(cashpaid != 0){
          aftercashpaid = grandTotal-cashpaid-$("#discount").val();
          $("#total_amount").val(aftercashpaid);
        }
        if(cashpaid == ""){
            $("#total_amount").val(grandTotal-$("#discount").val());
        }

        if(cash_paid != ""){
            $('#coamain').show();
            //$('#total_coa_balance').show();
            $('#coa').attr('required','required');
        }
        if($("#cash_paid").val() == ""){
            $('#coamain').hide();
            $('#coa').removeAttr('required','required');
            // $('#total_coa_balance').hide();
        }
        // if($('#total_coa_balance').val() != ""){
        //     var data =$('#total_coa_balance').val();
        //     if(parseInt(data) < parseInt($("#cash_paid").val()) ){
        //         $('#save_purchase').css('display','none');
        //     }
        //     else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
        //      $('#save_purchase').css('display','block');
        //     }
        // }
        // if($('#total_coa_balance').val() != ""){
        //     var data =$('#total_coa_balance').val();
        //     if(parseInt(data) < parseInt($("#cash_paid").val()) ){
        //         $('#save_purchase').css('display','none');
        //     }
        //     else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
        //      $('#save_purchase').css('display','block');
        //     }
        // }
        // if($("#total_amount").val() == 0){
        //         $('#cmn-toggle-1').attr("checked", false);
        //         $('#cmn-toggle-1').attr("disabled", true);
        //         $('#save_purchase').css('display','block');
        //     }
        //    else if($("#total_amount").val() != 0){
        //     $('#cmn-toggle-1').attr("checked", false);
        //     $('#cmn-toggle-1').attr("disabled", false);
        //     $('#save_purchase').css('display','none');    
        //     }
    })


}

$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    var coa1 =$('#coa').val();
     $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa1:coa1,_token:_token},
            success:function(data){
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    $('#coa').change(function(){ 
        var coa =$(this).val();
        $.ajax({
            type:'POST',
            url:'{{ url("purchase/gettotalbalance") }}',
            data:{coa:coa,_token:_token},
            success:function(data){
                $('#total_coa_balance').val("");
                $('#total_coa_balance').val(data);

                if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                    $('#save_purchase').css('display','none');
                }
                else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                    $('#save_purchase').css('display','block');
                }
            }
        });
    });
    
});
$(document).on('change', '.product_id', function(){
 var _token = $('input[name="_token"]').val();
    var product=this.value;
    var pro_id=$(this).attr('data-id');
          $.ajax({
           type: 'POST',
            dataType: 'json',
          url: '{{ url("purchase/products") }}',
          data: { product:product,_token:_token },
          success: function(data){

            
             $.each(data[0] , function(index , obj){

                $('.pro_des'+pro_id).val(obj.product_description);
                $('.s_price'+pro_id).val(obj.sale_price);
                $('.bags_qty'+pro_id).val(obj.bag_price);
            });

             $.each(data[1] , function(index,obj){

                $('.p_price' +pro_id).val(obj.sum/obj.count);
            });


         }
      });
});
$(document).ready(function () {
 var _token = $('input[name="_token"]').val();
    var cus=$('#cus').val();
          $.ajax({
           type: 'POST',
           dataType:'json',
          url: '{{ url("farmersale/credit_cash") }}',
          data: { cus:cus,_token:_token },
          success: function(data){
           
            $('#farmers_name').val(data[0]);
            $('#p_balance').val(data[1]);
         }
      });
});
$(document).on('change', '#cus', function(){
 var _token = $('input[name="_token"]').val();
    var cus=this.value;

          $.ajax({
           type: 'POST',
           dataType:'json',
           url: '{{ url("farmersale/credit_cash") }}',
           data: { cus:cus,_token:_token },
          success: function(data){
            $('#farmers_name').val(data[0]);
            $('#p_balance').val(data[1]);
         }
      });
});

$(document).on('change', '#total', function(){
    var total = $('#total').val();
    alert(total); 
});

function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
        }

</script>
  