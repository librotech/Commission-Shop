@extends('layouts.master')
@section('title', 'Accounts System-Design')
@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link active">Add New Design</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{ url('Design/view') }}">All Designs</a>
    </li>
</ul>
<br>
<div class="col-md-12">
<h3>Create A New Design</h3>
<hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
    @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
    @endif
    <form class="form-horizontal" method="POST" action="{{ url('Design/edit') }}">
    {{ csrf_field() }}
        <div class="row">
        <input type="hidden" name="recid" value="{{ $designs->designncode}}">
        <div class="col-md-3">
            <div class="form-group">
                <label for="dc">Design Code</label>
                <input id="name" type="text" class="form-control" name="desinecode" value="{{ $designs->designncode }}" required autofocus>
            </div>
        </div>
        <div class="col-md-3"></div>
        <div class="col-md-3"></div>
         <div class="col-md-3">
            <div class="form-group">
                <label for="dc">Date</label>
                <input value="{{ date('20y:m:d') }}" class="form-control" readonly="">
            </div>
        </div>
        <hr>
        <table class="table table-hover order-list table-responsive">
                <thead>
                <tr>
                    <th>Description</th>
                    <th>No of Stitches</th>
                    <th colspan="2">Machine Type</th>
                </tr>
                </thead>
                <tbody>
            @php $count=0; @endphp
            @foreach($designdetails as $designdetail)
                <tr>
                    <input type="hidden" name="subrecid[]" value="{{ $designdetail->id }}">
                    <td>
                    <input type="text" required="required"  name="description[]" readonly  class="form-control"  autocomplete="no" value="{{ $designdetail->description }}">
                    </td>
                    
                    <td><input type="number"  onkeypress="return isNumberKey(event,this)" required="required" min="0" id="no_stitch"  name="no_stitch[]" class="form-control no_stitch" value="{{ $designdetail->no_stitch }}"></td>
                    <td>
                        <?php 
                        $checked="";
                        $checked2="";
                        $checked5="";
                        $checked4="";
                        $checked6 = "";
                        // var_dump($designdetail->three30_type);
                        if($designdetail->m_type == "2.77") {
                            $checked="checked";
                        }
                        if($designdetail->m_type == "2.032") {
                            $checked2="checked";
                        }
                        if($designdetail->three30_type !== null){
                            
                            if($designdetail->three30_type === 1.0) {
                                $checked4="checked";
                            
                            }
                            else if( $designdetail->three30_type === 0.0 ){
                                $checked5 = "checked";
                                
                            }
                            else if( $designdetail->three30_type === 2.0 ){
                                $checked6 = "checked";
                                
                            }
                        }
                        ?>
                        <input type="radio" data-id='{{ $count }}' value="2.77" name="mtype[] m_type{{ $count }}" class="form-control first" <?php echo $checked ?>>330m
                        <hr>
                        <div id="multiradio_{{ $count }}">
                            
                          <input type="radio" value="0" {{ $checked5 }}  name="three30[{{ $count }}] three30_{{ $count }}">&nbsp Multilevel<br>
                          <input type="radio" value="1" {{ $checked4 }}  name="three30[{{ $count }}] three30_{{ $count }}">&nbsp Laser<br>
                           <input type="radio" value="2" {{ $checked6 }}  name="three30[{{ $count }}] three30_{{ $count }}">&nbsp None<br>
                        <div>
                    </td>
                    <td>
                        <input type="radio" data-id='{{ $count }}'  name="mtype[] m_type{{ $count }}" value="2.032" class="form-control second" <?php echo $checked2 ?>>450m 
                    </td>
                </tr>
            @php  $count++ @endphp
            @endforeach
            </tbody>

        </table>
        <hr>
        <div class="col-md-3">
            <div class="form-group">
                <button type="submit" class="btn btn-success" style="margin-top:33px;">
                    Update Design
                </button>
            </div>
        </div>
     </form>
  </div>
   </div>
<script type="text/javascript">
    $(document).ready(function(){
        $('.second').each(function(){
            var data_id = $(this).attr('data-id');
            var checked = $(this).attr('checked');
            if(checked){
                $('#multiradio_'+data_id).css('display','none');
            }
            
        });
       
        
    });
    $(document).on('click','.first',function(){
        var data_id = $(this).attr('data-id');
        alert(data_id);
        var checked = $(this).attr('checked')
        $('#multiradio_'+data_id).css('display','block');
    });

    $(document).on('click','.second',function(){
        var data_id = $(this).attr('data-id');
        var checked = $(this).attr('checked')
        $('#multiradio_'+data_id).css('display','none');
    });
</script>
@endsection
