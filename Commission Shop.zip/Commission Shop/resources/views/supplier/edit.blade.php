@extends('layouts.master')

@section('title', 'Accounts System-Suppliers')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('supplier/show') }}">View Suppliers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Update Supplier</a>
  </li>
  
</ul><br>
    <h3>Update Supplier</h3>
    <a href="{{ url('supplier/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Suppliers</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	     @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    @foreach($suppliers as $supplier)  
    <form action="{{ url('supplier/update') }}" method="post">
    	{{ csrf_field() }}
        
        <div class="row">
          <input type="hidden" name="supplier_id" value="{{ $supplier->id }}">
        <div class="col-md-3">
            <div class="form-group">
                <label>Suppplier Id</label>
                <input type="number" readonly="readonly" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57"  value="{{ $supplier->supplier_id }}" name="txt_supplier_id" class="form-control" placeholder="Enter Suuplier Id">
            </div>
        </div><div class="col-md-3">
            <div class="form-group">
                <label>Supplier Name</label>
                <input type="text" required="required" name="txt_supplier_name"  value="{{ $supplier->supplier_name}}"class="form-control" placeholder="Enter Supplier Name">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" required="required" style="overflow:auto;resize:none" rows="3" cols="3" name="supplier_address">{{ $supplier->addres }}</textarea>
            </div> 
        </div>
        @endforeach
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Update</button></div></div>
    </form>
@stop
