@extends('layouts.master')

@section('title', 'Accounts System-Farmers')

@section('content')

<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('farmer/show') }}">View Farmers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" href="{{ url('farmer/create') }}" >Add New Farmers</a>
  </li>
</ul><br>
    <h3>Add New Farmers</h3>
    <a href="{{ url('farmer/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Farmers</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('farmer.store') }}" method="post">
    	{{ csrf_field() }}
        <div class="row">
        <div class="col-md-2">
            <div class="form-group">
                <label>Farmer Id</label>
                @foreach($auto_increment as $ai)
                <input type="number" value="{{$ai->AUTO_INCREMENT }}"   name="txt_farmer_id" class="form-control" placeholder="Enter Farmer Id">
                @endforeach
            
            </div>
        </div><div class="col-md-2">
            <div class="form-group">
                <label>Farmer Name</label>
                <input type="text" required="required" name="txt_farmer_name" class="form-control" placeholder="Enter Farmer Name">
            </div>
            
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>Father Name</label>
                <input type="text" required="required" name="txt_father_name" class="form-control" placeholder="Enter Father Name">
            </div>
            
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>Contact No.</label>
                <input type="number" required="required" name="txt_farmer_contact" class="form-control" placeholder="Enter contact number">
            </div>
            
        </div>
        
        <div class="col-md-4">
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" required="required" style="overflow:auto;resize:none" rows="3" cols="3" name="txt_farmer_address"></textarea>
            </div> 
        </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Save</button></div></div>
    </form>
@stop
