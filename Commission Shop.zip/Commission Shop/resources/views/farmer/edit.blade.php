@extends('layouts.master')

@section('title', 'Accounts System-Farmers')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('farmer/show') }}">View Farmers</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Update Farmer</a>
  </li>
  
</ul><br>
    <h3>Update Farmer</h3>
    <a href="{{ url('farmer/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Farmers</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	     @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    @foreach($single_farmer as $farmer) 
    <form action="{{ url('farmer/update') }}" method="post">
    	{{ csrf_field() }}
        
        <div class="row">
       
        <div class="col-md-2">
            <div class="form-group">
                <label>Farmer Id</label>
                <input type="number" readonly="readonly" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57"  value="{{ $farmer->farmers_id }}" name="txt_farmer_id" class="form-control" placeholder="Enter farmer Id">
            </div>
        </div><div class="col-md-2">
            <div class="form-group">
                <label>Farmer Name</label>
                <input type="text" required="required" name="txt_farmer_name"  value="{{ $farmer->farmers_name}}"class="form-control" placeholder="Enter farmer Name">
            </div>
            
        </div>
        <div class="col-md-2">
            <div class="form-group">
                <label>Father Name</label>
                <input type="text" required="required" name="txt_father_name"  value="{{ $farmer->father_name}}"class="form-control" placeholder="Enter father Name">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Contact</label>
                <input type="number" required="required" name="contact"  value="{{ $farmer->contact_no}}"class="form-control" placeholder="Enter Contact No.">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Address</label>
                <textarea class="form-control" required="required" style="overflow:auto;resize:none" rows="3" cols="3" name="address">{{ $farmer->address }}</textarea>
            </div> 
        </div>
        </div>
        @endforeach
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Update</button></div></div>
    </form>
@stop
