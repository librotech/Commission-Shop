@extends('layouts.master')

@section('title', 'Accounts System-Fundstransefer')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " >View Funds Transfer</a>
  </li>
  <li class="nav-item active" >
    <a class="nav-link " href="{{ url('fundstranser/add') }}">Transfer Fund</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Funds Transferred</h3> <a href="{{ url('fundstranser/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Transfer Funds</a>
    <hr>
   <table class="table table-striped table-bordered dataTable" id="example">
    	<thead>
      <tr>
    		<th>SNo.</th>
    		<th>fund id</th>
    		<th>From</th>
    		<th>To</th>
    		<th>Date</th>

    	</tr>
      </thead>
      <tbody>
    	@foreach($funds as $fund)
    		<tr>
    			<td>{{ $loop->iteration }}</td>
    			<td>{{ $fund->id }}</td>
    			<td>{{ $fund->from_coa_id }}</td>
    			<td>{{ $fund->to_coa_id }}</td>
    			<td>{{ $fund->created_at }}</td>
    		</tr>
    	@endforeach
      </tbody>
      <tfoot>
        <th>SNo.</th>
        <th>fund id</th>
        <th>From</th>
        <th>To</th>
        <th>Date</th>
      </tfoot>
    </table>
    {{ $funds->links() }}
@stop
