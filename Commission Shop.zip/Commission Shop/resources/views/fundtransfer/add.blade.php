@extends('layouts.master')

@section('title', 'Accounts System-Fundstransefer')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('fundtransfer/show') }}">View Funds Transfer</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Funds Transfer</a>
  </li>
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Funds Transfer</h3>
    <a href="{{ url('fundtransfer/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Funds Transfer</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('fundtransfer/add') }}" id="myForm" method="post">
    	{{ csrf_field() }}
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                <label>From</label>
                <select name="from" class="form-control">
                @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}
                    </option>
                @endforeach
                </select>
            </div>
            </div>
            <div class="col-md-3">
               <h5 style="margin-top:40px;margin-left:60px;"><b >--------></b></h5>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>To</label>
                <select name="to" class="form-control">
                @foreach($chartofaccounts as $chartofaccount)
                    <option value="{{ $chartofaccount->acc_id }}">{{ $chartofaccount->acc_title }}
                    </option>
                @endforeach
                </select>
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Ammount</label>
                <input type="number" required="required" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="amount" class="form-control" autofocus>
            </div>
            </div>
        </div>
            
             
        <button class="btn btn-block btn-success">Transfer</button>
    </form>
@stop

<script type="text/javascript">
    $(document).ready(function(){
        var formProcessing = false;
        $("#myForm").on("submit", function(e) {
            
            e.preventDefault();
            
            if( formProcessing )
                return;

            formProcessing = true;
            $("#myForm").get(0).submit();
            
        });
    });
</script>