@extends('layouts.master')

@section('title', 'Accounts System-Return Purchase')

@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('debitnotes/add') }}">Return Purchase</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">All Purchase Return</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>All Purchase Return</h3> <a href="{{ url('debitnotes/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Return Purchase</a>
    <hr>

   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>SNo.</th>
            <th>Debitnote Id</th>
            <th>supplier</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
        </tr>
        </thead>
        <tbody>
         @foreach($debitnotes as $debitnote)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $debitnote->id }}</td>
                <td>{{ $debitnote->supplier_name }}</td>
                <td>{{ $debitnote->total }}</td>
                <td>{{ $debitnote->name }}</td>
                <td>{{ date('d-m-Y', strtotime($debitnote->created_at))}}</td>
                <td><a href="{{ url('debitnote/void/'.$debitnote->id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This Purchase debitnote?');">Void</a></td>
            </tr>
            
        @endforeach
      </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Debitnote Id</th>
            <th>supplier</th>
            <th>Amount</th>
            <th>user</th>
            <th>Date</th>
            <th>void</th>
            </tr>
        </tfoot>
    </table>
@stop
