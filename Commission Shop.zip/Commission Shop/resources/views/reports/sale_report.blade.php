@extends('layouts.master')

@section('title', 'Accounts System-Cash Sales Report')
<style type="text/css">
    
</style>
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Sales Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
    <h3>Sales Reports</h3>
    <hr>
   <ul class="nav nav-tabs" role="tablist">
        <li class="nav-item" >
            <a class="nav-link" href="#" data-toggle="tab" id="daily" role="tab">Daily Sales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" data-toggle="tab" id="weekly" role="tab">Weekly Sales</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active" href="#" data-toggle="tab" id="monthly" role="tab" >Monthly Sales</a>
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspFrom</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" placeholder="Select Date" readonly="" id="datepicker"  class="form-control">&nbsp
        </li>
        <li class="nav-item"><b>&nbsp&nbsp&nbspTo</b>&nbsp&nbsp</li>
        <li class="nav-item">
            <input type="text" placeholder="Select Date" readonly="" id="datepicker2"  class="form-control">&nbsp
        </li>
       
    </ul>
<!-- Tab panes -->
<div class="tab-content">
    <div class="tab-pane active" id="home" role="tabpanel">
    <div >
        <hr>
    <h3 id="heading">Monthly Sales</h3>
    <hr>
    <div class="row">
     <div class="col-md-3">
      <div class="form-group">
                <label>Customers Id</label>
                <input class="form-control" required="required" name="txt_customer" required="required" id="customer"  placeholder="Select Customers" class="form-control" list="customers">
                    <datalist id="customers">
                    @foreach($customers as $customer)
                        <option value="{{ $customer->customer_id }}"><b>{{ $customer->customer_name }}</b></option>
                    @endforeach
                    </datalist> 
                </select>
            </div>
          </div>
           <div class="col-md-3">
            <div class="form-group">
                <label>Customer Name</label>
                <input type="text"  readonly="readonly" id="customer_description" name="txt_customer_description" class="form-control" placeholder="Enter customer Description">
            </div>
        </div>
          <div class="col-md-3">
      <div class="form-group">
                <label>Product Id</label>
                <input class="form-control" required="required" name="txt_product" required="required" id="product"  placeholder="Select product" class="form-control" list="products">
                    <datalist id="products">
                    @foreach($products as $product)
                        <option value="{{ $product->product_id }}"><b>{{ $product->product_description }}</b></option>
                    @endforeach
                    </datalist> 
                </select>
            </div>
          </div>
           <div class="col-md-3">
            <div class="form-group">
                <label>Product Name</label>
                <input type="text"  readonly="readonly" id="product_description" name="txt_product_description" class="form-control" placeholder="Enter product Description">
            </div>
        </div>
        </div>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
            <th>Bill ID</th>
            <th>Name</th>
            <th>Product</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="cashsale">
        
    </tbody>
    <tfoot>
            <tr>
            <th>Bill ID</th>
            <th>Name</th>
            <th>Product</th>
            <th>Cost Price</th>
            <th>Quantity</th>
            <th>Amount</th>
            <th>Date</th>

            </tr>
        </tfoot>
        
    </table>
   
    </div>
    </div>
</div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">

    $(document).ready(function(){
        $('#customer,#datepicker,#datepicker2').on('change', function() {

        var _token   = $('input[name="_token"]').val();
        var customer = $('#customer').val();
        var to       = $('#datepicker').val();
        var from     = $('#datepicker2').val();


        if(customer != ''){
            $.ajax({
            type: 'POST',
            url: '{{url("report/populate_customer_description")}}',
            data: { 
                customer,
                to,
                from,
                _token:_token },
            dataType: 'json',
            success: function(data) {
                var row ='';
                $.each(data[0],function(i,obj){
                $('#customer_description').val(obj.customer_name);
            })
                
                $.each(data[1],function(i,obj){

                    
                    row += 

                            '<tr><td><a href="{{url("sale/show/")}}/'+obj.id+'">'
                            +obj.id+
                            '</a></td><td>'
                            +obj.product_description+
                            '</td><td>'
                            +obj.customer_name+
                            '</td><td>'
                            +obj.sale_price+
                            '</td><td>'
                            +obj.qty+
                            '</td><td>'
                            +obj.inlinetotal+
                            '</td><td>'
                            +obj.date+
                            '</td></tr>';
                      

                })
              
              $('#cashsale').html(row);
                }
            });
       
        }
    });
  });

$(document).ready(function(){
    $('#product, #datepicker, #datepicker2').on('change' ,function(){


        var _token   = $('input[name="_token"]').val();
        var product = $('#product').val();
        var to      = $('#datepicker').val();
        var from    = $('#datepicker2').val();

        $.ajax({
            type:'post',
            url:'{{url("report/populate_sales")}}',
            data:{
                product,
                to,
                from,
                _token:_token
            },
            dataType:'json',
            success:function(data){
                $.each(data[0],function(index,obj){
                    $('#product_description').val(obj.product_description);
                })

                var row = '';
                 $.each(data[1],function(i,obj){
                    row += 

                        '<tr><td><a href="{{url("sale/show/")}}/'+obj.inv_id+'">'
                        +obj.inv_id+
                        '</a></td><td>'
                        +obj.customer_name+
                        '</td><td>'
                        +obj.product_description+
                        '</td><td>'
                        +obj.sale_price+
                        '</td><td>'
                        +obj.qty+
                        '</td><td>'
                        +obj.inlinetotal+
                        '</td><td>'
                        +obj.created_at+
                        '</td></tr>';                

                })

                var endRow ='';
                $.each(data[2],function(index,obj){

                    endRow += '<tr><td></td><td></td><td></td><td></td><td>Total Sales</td><td>'
                    +obj.total.toFixed(2)+
                    '</td><td></td></tr>'
                })
                 $('#cashsale').html(row); 
                 $('#cashsale').append(endRow); 
            }

        });
        });

});


function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;


}
window.onafterprint = function(){
      window.location.reload(true);
 }

</script>