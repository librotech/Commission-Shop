@extends('layouts.master')

@section('title', 'Accounts System-Ledger Report 2019')
@section('content')
<ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('report/view') }}">Reports</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active">Ledger Report</a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    </ul>
<br>
<div id="HTMLtoPDF" style="width:100%">
<h3>Ledger Report</h3>
<hr>
<div class="row">
	<div class="col-md-3">
		<input type="text" name="account" id="account" class="form-control" list="accounts">
		<datalist id="accounts">
			@foreach($accounts as $account)
			<option value="{{ $account->account_id }}">{{ $account->coa_title }}</option>
			@endforeach
		</datalist>
	</div>
</div>
<table class="table table-hover" style="width:100%;text-align:left;">
	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           
            <th>Account Title</th>
            <th>Transection Type</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Balance</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody id="report">
        	
        </tbody>
    <tfoot>
            <tr>
            <th>Account Title</th>
            <th>Transection Type</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Balance</th>
            <th>Date</th>
            </tr>
        </tfoot>
    </table>
</table>
</div>
@stop

<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
	$(document).on('change','#account',function(){
		var account =$(this).val();
		var _token = $('input[name="_token"]').val();
		var table = $('#example').DataTable();
		//alert(account);
		$.ajax({
		  url: '{{ url("reports/coalegreport") }}',
		  type: 'POST',
		  data:{account:account,_token:_token},
		  dataType: 'json',
		success: function(data){
                var row="";
                var account_type="";
                 $.each(data, function (index, obj) {
                   row += "<tr><td>" + obj.coa_title + "</td>";
                   if(obj.transection_type == 1){
	                   row += "<td>Purchase</td>";
	                   account_type ="Purchase";
                   }
               	  else if(obj.transection_type == 2){
               	   row += "<td>Invoice # "+obj.ref_id+"</td>";
               		account_type ="Invoice # "+obj.ref_id;}
               	   else if(obj.transection_type == 4){
               	   row += "<td>Sale Return</td>";
               	   account_type ="Sale Return";}
               	  else if(obj.transection_type == 5){
               	   row += "<td>Journal Entries</td>";
               	    account_type ="Journal Entries";}
               	   else if(obj.transection_type == 6){
               	   row += "<td>Expense</td>";
               		account_type ="Expense";}
                else if(obj.transection_type == 7){
               	   row += "<td>Funds Transfer</td>";
               	   account_type ="Funds Transfer";}
                else if(obj.transection_type == 8){
               	   	row += "<td>Cash Paid</td>";
               		account_type ="Cash Paid";}
               	else if(obj.transection_type == 9){
               	    row += "<td>Cash Recieved</td>";
               		account_type ="Cash Recieved";}
               	else	if(obj.transection_type == 10){
               	   row += "<td>Stitching Unit</td>";
               		account_type ="Stitching Unit";}
               	else	if(obj.transection_type == 11){
               	   row += "<td>Invoice # "+obj.ref_id+"</td>";
               	   account_type ="Invoice # "+obj.ref_id;}
               	else if(obj.transection_type == 20){
               	   row += "<td>Pay Roll</td>";
               		account_type ="Pay Roll";}
               	   else if(obj.transection_type == 21){
               	   row += "<td>Pay Advance</td>";
               	account_type ="Pay Advance";}
	               else{
	               	row += "<td>Some Account</td>";
	               account_type ="Some Account";}
                    if(obj.debit_ammount != null){
                   row +="<td>" + obj.debit_ammount + "</td>";}
                   else{ row +="<td></td>";}
                   
                    if(obj.credit_ammount != null){
                   row +="<td>" + obj.credit_ammount + "</td>";}
                   else{ row +="<td></td>";}
                   
                   row +="<td>" + obj.balance + "</td><td>" + obj.date + "</td></tr>";
                    
                  table.row.add([
			obj.coa_title,account_type, obj.debit_ammount,obj.credit_ammount,+obj.balance,obj.date]).draw();
                   
                });
                 //alert(row);
                  $('#report').html(row);
              }
		});	
	});
</script>