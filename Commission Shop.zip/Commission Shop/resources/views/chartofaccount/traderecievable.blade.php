@extends('layouts.master')

@section('title', 'Accounts System-Trade Recieveable')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('coa/show') }}">Chart Of Account</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Trade Recieveable</a>
  </li>
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Trade Recieveable</h3> <a href="{{ url('coa/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Chart Of Account</a>
    <hr>
    <table class="table table-responsive">
        <tr>
            <th>Account id</th>
            <th>Account Name</th>
            <th>Balance</th>
        </tr>
        @foreach($recieveables as $recievable)
        <tr>
            @if($recievable->account_type == 3 && $recievable->balance < 0 || $recievable->account_type == 2 && $recievable->balance < 0 )
            <td>{{ $recievable->account_id }}</td>
            <td><a >{{ $recievable->coa_title }}</a></td>
            <td><a >{{ $recievable->balance }}</a></td>
            @elseif($recievable->account_type == 1 && $recievable->balance > 0 && strpos($recievable->account_id, 'customer_') !== false)
             <td>{{ $recievable->account_id }}</td>
            <td><a >{{ $recievable->coa_title }}</a></td>
            <td><a >{{ $recievable->balance }}</a></td>
            @endif
        </tr>
        @endforeach
    </table>
@stop
