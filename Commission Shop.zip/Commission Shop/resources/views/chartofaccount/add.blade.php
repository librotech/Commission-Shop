@extends('layouts.master')

@section('title', 'Accounts System-Chart Of Account')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('coa/show') }}">View Chart Of Accounts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active"  >New Chart Of Account</a>
  </li>
</ul><br>
    <h3>New Chart Of Account</h3>
    <a href="{{ url('coa/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Chart Of Accounts</a>
    <hr>
    @if(count($errors) > 0)
    	@foreach($errors->all() as $error)
    		<p class="alert alert-danger">{{ $error }}</p>
    	@endforeach
    @endif
	    @if(session()->has('message.level'))
	    <div class="alert alert-{{ session('message.level') }}"> 
	    {!! session('message.content') !!}
	    </div>
		@endif
    <form action="{{ url('coa/store') }}" method="post">
    	{{ csrf_field() }}
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                <label>Account id</label>
                <input type="text" required="required"  onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_acc_id" class="form-control" placeholder="Enter Account id" autofocus>
            </div>
            </div>
            <div class="col-md-3">
               <div class="form-group">
                <label>Account Title</label>
                <input type="text" required="required"  name="txt_acc_title" class="form-control" placeholder="Enter Account Title">
            </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Account Type</label>
                <select class="form-control" id="txt_account_type" name="txt_account_type">
                    <option value="1">Asset</option>
                    <option value="2">Liabilities</option>
                    <option value="3">Capital</option>
                    <option value="4">Income</option>
                    <option value="5">Expense</option>
                    <option value="6">Fixed asset</option>

                </select>
                
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                <label>Account Description</label>
                <textarea class="form-control"  style="overflow:auto;resize:none" rows="3" cols="3" name="account_description"></textarea>
            </div>
            </div>
           
            
        </div>
        
       <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">      
        <button class="btn btn-block btn-success">Save</button></div></div>
    </form>
    <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <h5>Add New Fixed Account</h5>
            
          </div>
          <div class="modal-body">

                <div class="row">
                <div class="col-md-12"><div id="message" style="display:none;"></div></div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Bill id</label>
                        <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="bill_id" class="form-control" id="bill_id" placeholder="Enter Bill No">
                    </div>
                    </div>
                    <div class="col-md-6">
                       <div class="form-group">
                        <label>Date</label>
                        <input type="text" name="dateed" readonly id
                    ="datepicker" value="{{ date('20y-m-d') }}" class="form-control" placeholder="Enter date">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Supllier</label>
                        <select class="form-control" name="txt_account_type" id="sup">
                            <option value="">Select</option>
                            @foreach($suppliers as $supplier)
                            <option value="{{ $supplier->supplier_id }}">{{ $supplier->supplier_name }}</option>
                            @endforeach
                        </select>
                        
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Asset Name</label>
                        <input type="text" name="ass_name" class="form-control" id="ass_name" placeholder="Enter Asset Name">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Despriciation Rate</label>
                        <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="dp_rate" class="form-control" id="dpr" placeholder="Enter Despriciation Rate as %">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Amount</label>
                        <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="amount" class="form-control" id="amo" placeholder="Enter Amount">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label></label>
                            <select class="form-control" id="coa">
                                @foreach($chartofaccounts as $coa)
                                <option value="{{ $coa->acc_id }}">{{ $coa->acc_title }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                        <label>Cash Paid</label>
                        <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="cp" class="form-control" id="cp" placeholder="Enter Cash Paid">
                    </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                        <label>Remaining Balance</label>
                        <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="rm" class="form-control" id="rm" placeholder="Remaining Balance">
                    </div>
                    </div>
                   
                    
                </div>
          </div>
          <div class="modal-footer">
            <button class="btn  btn-success" id="save-fass">Save</button><button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
        </div>

      </div>
    </div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#txt_account_type').change(function(){
        if($(this).val() == 6){
            $('#myModal').modal('show');
            $("#txt_account_type").val($("#txt_account_type option:first").val());
        }
    });

    $('#cp').keyup(function(){
        if($('#amo').val() != ""){
           $('#rm').val($('#amo').val()-$(this).val());
        }
         if($(this).val() == ""){
            $('#rm').val($('#amo').val()-$(this).val());
         }
         if($('#rm').val() < 0){
            $('#save-fass').attr('disabled',true);
         }
          if($('#rm').val() > 0){
            $('#save-fass').attr('disabled',false);
         }
    });
    $('#amo').keyup(function(){

        if($('#cp').val() != ""){
           $('#rm').val($(this).val()-$('#cp').val());
        }
        if($(this).val() != ""){
            $('#rm').val($(this).val()-$('#cp').val());
         }
         if($('#rm').val() < 0){
            $('#save-fass').attr('disabled',true);
         }
          if($('#rm').val() > 0){
            $('#save-fass').attr('disabled',false);
         }
    });

    $('#save-fass').click(function(){
        var bill=$('#bill_id').val();
        var datepicker=$('#datepicker').val();
        var sup=$('#sup').val();
        var ass_name=$('#ass_name').val();
        var dpr=$('#dpr').val();
        var amo=$('#amo').val();
        var cp=$('#cp').val();
        var rm=$('#rm').val();
        var coa=$('#coa').val();
        if(bill == "" || datepicker == "" || sup == "" || ass_name == "" || dpr == "" || amo == "" || cp == "" || rm == "") {

             $('#message').show();
                    $('#message').attr('class','alert alert-danger');
                    $('#message').html('All Fields are Required');
        }
        else{
            var _token = $('input[name="_token"]').val();
            $.ajax({
                url:'{{ url("coa/addfixaccount") }}',
                type:'post',
                data:{_token:_token,bill:bill,datepicker:datepicker,sup:sup,ass_name:ass_name,dpr:dpr,amo:amo,cp:cp,rm:rm,coa:coa},
                success:function(response){
                    if(response == 2){
                    $('#message').show();
                    $('#message').attr('class','alert alert-success');
                    $('#message').html('Fixd Asset added SuccessFully');
                    }
                    else if(response == 1){
                    $('#message').show();
                    $('#message').attr('class','alert alert-danger');
                    $('#message').html('bill id or asset name must be difference');
                    }
                }
            });
        }

    });
});

</script>