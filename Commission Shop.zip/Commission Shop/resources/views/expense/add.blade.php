@extends('layouts.master')

@section('title', 'Accounts System-Add New Purchase')

@section('content')
<ul class="nav nav-tabs">
     <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">New Expense</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('expense/show') }}">View Expense</a>
  </li>
 
</ul><br>
    <h3>New Expense</h3>
    <a href="{{ url('expense/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Expense</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('expense/save') }}" id="myForm" method="post">

    	<div class="row">
    	<!-- <div class="col-md-3">
    		<div class="form-group">
    			<label>Bill id</label>
    			<input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" required="required" autocomplete="off" name="txt_bill_no" list="bill_id" class="form-control" placeholder="Enter Bill No">
                <datalist id="bill_id">
                @foreach($bills as $bill)
                        <option value="{{ $bill->bll_id }}">
                @endforeach
                </datalist>
    		</div>
        </div> -->
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" required="required" id="datepicker" autocomplete="off" value="<?php echo "20".date('y-m-d', time()); ?>" style="background:white !important;" readonly name="txt_date" class="form-control" placeholder="Enter Date of Bill" autofocus>
    		</div>
    	</div>
    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Account Code</th>
    				<th>Account</th>
    				<th>Amount</th>
    			</tr>
    			</thead>
    			<tbody>
    			<tr>
    				<td><input type="text" autocomplete="off" id="coa_id" name="txt_coa_id" class="form-control" required="required" placeholder="Chart Of Account Id" list="coa">
                    <datalist id="coa">
                    @foreach($chartofaccounts as  $chartofaccount)
                        <option value="{{ $chartofaccount->coa_id }}"><b>{{ $chartofaccount->coa_title }}</b></option>
                    @endforeach
                    </datalist>
                    </td>

                    <td><input type="text" readonly="readonly" id="coa_desc" name="txt_coa_description" class="form-control" placeholder="Chart Of Description"></td>
    				<td><input type="number" min="0" readonly="readonly" id="ammount" required="required" name="txt_expense_amount" class="form-control txt_amount linetotal" placeholder="Amount"></td>
    			</tr>
    		</tbody>

    	</table>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-3">
                <label>Account</label>
                <select class="form-control"  name="coa" style="display:none;" id="asset_accounts">
                    @foreach($assets as $asset)
                    <option value="{{ $asset->acc_id }}">{{ $asset->acc_title }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>Cash Available</label>
                <input type="number" min="0" readonly="readonly" style="display:none;" name="cash_available" id="total_coa_balance" class="form-control">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
             <div class="col-md-3"><button id="save_expense" class="btn btn-block btn-success btn-block">Save</button></div>
            
        </div>
        
        {{ csrf_field() }}
    </form>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    $("#coa_id").change(function(){
        var coa_id=this.value;
          $.ajax({
           type: 'POST',
           url: '{{ url("expense/populate_coa_description") }}',
          data: { coa_id:coa_id,_token:_token },
           success: function(data){
               $("#coa_desc").val(data);
         }
        });
    });
    // $('#ammount').keyup(function(){
    //     var ammount=$(this).val();
    //   if(ammount != $('#cash_paid').val()){
    //         $('#save_expense').css('display','none');
    //     }
    //     else if(ammount == $('#cash_paid').val()){
    //         $('#save_expense').css('display','block');
    //     }  
    // });
    $("#cash_paid").keyup(function(){
        var cash_paid=$(this).val();
        
        $('#ammount').val(cash_paid);
        if(cash_paid != ""){
            $('#asset_accounts').css('display','block');
            $('#total_coa_balance').show();
            $('#asset_accounts').attr('required','required');
        }
        if(cash_paid == ""){
            $('#asset_accounts').hide();
            $('#total_coa_balance').hide();
        }
        if(cash_paid != $('#ammount').val()){
            $('#save_expense').css('display','none');
        }
        else if(cash_paid == $('#ammount').val()){
            $('#save_expense').css('display','block');
        }
        if($('#total_coa_balance').val() != ""){
            var data =$('#total_coa_balance').val();
            if(parseInt(data) != parseInt($("#cash_paid").val()) && parseInt($('#ammount').val()) != parseInt($("#cash_paid").val())){
                    $('#save_expense').css('display','none');
                }
                else if (parseInt(data) == parseInt($("#cash_paid").val()) && parseInt($('#ammount').val()) == parseInt($("#cash_paid").val())) {
                    $('#save_expense').css('display','block');
                }
        }
    })
      var formProcessing = false;
    jQuery("#myForm").on("submit", function(e) {
        
        e.preventDefault();
        
        if( formProcessing )
            return;

        formProcessing = true;
        jQuery("#myForm").get(0).submit();
        
    });
});
$(document).ready(function(){
var _token = $('input[name="_token"]').val();
var coa1 =$('#asset_accounts').val();
 $.ajax({
        type:'POST',
        url:'{{ url("purchase/gettotalbalance") }}',
        data:{coa1:coa1,_token:_token},
        success:function(data){
            $('#total_coa_balance').val(data);

            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                $('#save_purchase').css('display','block');
            }
        }
    });
$('#asset_accounts').change(function(){ 
    var coa =$(this).val();
    $.ajax({
        type:'POST',
        url:'{{ url("purchase/gettotalbalance") }}',
        data:{coa:coa,_token:_token},
        success:function(data){
            $('#total_coa_balance').val("");
            $('#total_coa_balance').val(data);

            if(parseInt(data) < parseInt($("#cash_paid").val()) ){
                $('#save_purchase').css('display','none');
            }
            else if (parseInt(data) > parseInt($("#cash_paid").val()) ) {
                $('#save_purchase').css('display','block');
            }
        }
    });
});

});
</script>