@extends('layouts.master')

@section('title', 'Accounts System-Add New Purchase')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ url('expense/show') }}">View Expenses</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active" >Update Expense</a>
  </li>
</ul><br>
    <h3>Update Expense</h3>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form action="{{ url('expense/update') }}" id="myForm" method="post">
        @foreach($expenses as $expense)
        <div class="row">
        <!-- <div class="col-md-3"></div> -->
        <!-- <div class="col-md-3">
            <div class="form-group">
                
                <label>Bill id</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $expense->bill_id }}" name="txt_bill_no" list="bill_id" class="form-control" placeholder="Enter Bill No">
                <datalist id="bill_id">
                @foreach($bills as $bill)
                        <option value="{{ $bill->id }}"></option>
                @endforeach
                </datalist>
            </div>
        </div> -->
        <input type="hidden" name="rec_id" value="{{ $expense->id }}">
        <div class="col-md-3">
            <div class="form-group">
                <label>Date</label>
                <input type="text" value="{{ $expense->date }}"  id="datepicker" autocomplete="off" name="txt_date" class="form-control" placeholder="Enter Date of Bill">
            </div>
        </div>
        </div>
        <table class="table table-hover order-list">
                <thead>
                <tr>
                    <th>Account Code</th>
                    <th>Account</th>
                    <th>Amount</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><input type="text" value="{{ $expense->coa_id }}" id="coa_id" name="txt_coa_id" class="form-control" placeholder="Chart Of Account Id" list="coa">
                    <datalist id="coa">
                    @foreach($chartofaccounts as  $chartofaccount)
                        <option value="{{ $chartofaccount->coa_id }}"><b>{{ $chartofaccount->coa_title }}</b></option>
                    @endforeach
                    </datalist>
                    </td>

                    <td><input type="text" value="{{ $expense->coa_description }}" readonly="readonly" id="coa_desc" name="txt_coa_description" class="form-control" placeholder="Chart Of Description"></td>
                    <td><input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $expense->expense_amount }}" id="ammount"  name="txt_expense_amount" class="form-control txt_amount linetotal" placeholder="Amount"></td>
                </tr>
            </tbody>
            @endforeach
        </table>
        <div class="row">
            <div class="col-md-9"></div>
             <div class="col-md-3"><button class="btn btn-block btn-success btn-block">Save</button></div>
            
        </div>
        
        {{ csrf_field() }}
    </form>
@stop
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    var _token = $('input[name="_token"]').val();
    $("#coa_id").change(function(){
        var coa_id=this.value;
          $.ajax({
           type: 'POST',
           url: 'http://127.0.0.1:8000/expense/populate_coa_description',
          data: { coa_id:coa_id,_token:_token },
           success: function(data){
               $("#coa_desc").val(data);
         }
        });
    });
      
});
</script>