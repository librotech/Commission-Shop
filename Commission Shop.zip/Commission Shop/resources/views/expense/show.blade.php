@extends('layouts.master')

@section('title', 'Accounts System-Add New Purchase')

@section('content')

    <h3>Add New Expense</h3>
    <a href="{{ url('expense/show') }}" class="btn btn-info" style="float:right;margin-top:-40px;">View Expenses</a>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    @foreach($expenses as $expense)
    <form action="{{ url('expense/save') }}" id="myForm" method="post">

    	<div class="row">
    	<div class="col-md-6">
    		<div class="form-group">
    			<label>Bill id</label>
    			<input type="number" class="form-control" value="{{ $expense->bill_id }}">
    		</div>
        </div><div class="col-md-6">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text" class="form-control" value="{{ $expense->date }}">
    		</div>
    	</div>
    	</div>
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Chart of Account id</th>
    				<th>Amount</th>
    			</tr>
    			</thead>
    			<tbody>
    			<tr>
    				<td><input type="text" autocomplete="off" id="coa_id" name="txt_coa_id" class="form-control" value="expense_{{ $expense->coa_id }}">
                    </td>
    				<td><input type="number" min="0" class="form-control" value="{{ $expense->expense_amount }}"></td>
    			</tr>
    		</tbody>

    	</table>
        <!-- <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" placeholder="please enter advance amount" id="cash_paid" name="cash_paid" class="form-control">
                </div>
            </div>
        </div> -->
        {{ csrf_field() }}
    </form>
    @endforeach
@stop
