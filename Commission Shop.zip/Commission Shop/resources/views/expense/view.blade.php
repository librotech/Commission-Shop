@extends('layouts.master')

@section('title', 'Accounts System-All Expenses')

@section('content')
<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('expense/add') }}">New Expense</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active"  >View Expense</a>
  </li>
 
</ul><br>
    <h3>All Expense Receipts</h3> <a href="{{ url('expense/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">New Expense</a>
    <hr>
	
   <table id="example" class="table table-striped table-bordered" style="width:100%">
    <thead>
    	<tr>
    		<th>SNo.</th>
    		<th>Expense id</th>
            <th>Expense Amount</th>
            <th>Account Description</th>
            <th>User</th>
    		<th>Date</th>
            <th>Void</th>
    		<th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
    	</tr>
    </thead>
    <tbody>
    	@foreach($expenses as $expense)
    		<tr>
    			<td>{{ $loop->iteration }}</td>
    			<td>{{ $expense->id }}</td>
                <td>{{ $expense->expense_amount }}</td>
                <td>{{ $expense->coa_title }}</td>
                <td>{{ $expense->name }}</td>
    			<td>{{ date('d-m-Y', strtotime($expense->created_at))}}</td>
                <td><a href="{{ url('expense/void/'.$expense->id) }}" class="btn btn-info btn-sm" onclick="return confirm('you want to Void this Record?');">Void</a></td>
    			<td><a href="{{ url('expense/show/'.$expense->id)}}" class="btn btn-success btn-sm">Edit</a></td>
                 @if(Auth::user()->role == 1)
                <td><a href="{{ url('expense/delete/'.$expense->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
    		</tr>
    	@endforeach
        </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Expense id</th>
            <th>Expense Account</th>
            <th>Account Description</th>
            <th>User</th>
            <th>Date</th>
            <th>Void</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>

@stop
