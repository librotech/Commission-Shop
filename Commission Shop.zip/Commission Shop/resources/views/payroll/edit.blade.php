@extends('layouts.master')

@section('title', 'Accounts System-Pay Roll')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('product/show') }}">View Products</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">Update Product</a>
  </li>
  
</ul><br>
    <h3>Update Product</h3>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
     <form action="{{ url('product/update') }}" method="post">
        {{ csrf_field() }}
        <div class="row">
            @foreach($products as $product)
            <input type="hidden" name="txt_rec_id" value="{{ $product->id }}">
        <div class="col-md-3">
            <div class="form-group">
                <label>Product Id</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_product_id"  value="{{ $product->product_id }}" class="form-control" placeholder="Enter Product Id">
            </div>
            </div><div class="col-md-3">
            <div class="form-group">
                <label>Sale Price</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" name="txt_sale_price"  value="{{ $product->sale_price }}" class="form-control" placeholder="Enter Sale Price">
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Product Description</label>
                <input type="text" name="txt_product_description" value="{{ $product->product_description }}" class="form-control" placeholder="Enter Product Description">
            </div>
        </div><div class="col-md-3">
            <div class="form-group">
                <label>Stock Alert</label>
                <input type="number" min="0" onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57" value="{{ $product->stock_alert }}" name="txt_stock_alert" class="form-control" placeholder="Enter Stock Alert">
            </div>
            
        </div>
        @endforeach
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
        <button class="btn btn-block btn-success">Update</button></div></div>
    </form>

@stop
