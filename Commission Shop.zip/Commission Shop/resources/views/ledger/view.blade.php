@extends('layouts.master')

@section('title', 'Accounts System-Ledger Report')
@section('content')

<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">All Ledger Enteries</a>
  </li>
</ul><br>
    <h3>All Ledger Enteries</h3>
    <hr>
         <table id="example"  class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           <th>Ledger no</th>
            <th>Account Title</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Balance</th>
            <th>Date</th>
        </tr>
        </thead>
        <tbody>
        @foreach($ledgers as $ledger)
            <tr>
                <td>{{ $ledger->lid }}</td>
                @if(strpos($ledger->account_id, 'ade_') !== false)
                <td>{{ 'ADE_'.$ledger->coa_title }}</td>
                @elseif(strpos($ledger->account_id, 'de_') !== false)
                <td>{{ 'DE_'.$ledger->coa_title }}</td>
                @else
                <td>{{ $ledger->coa_title }}</td>
                @endif

                <td>{{ $ledger->debit_ammount}}</td>
                <td>{{ $ledger->credit_ammount}}</td>
                <td>{{ round($ledger->balance,2)}}</td>
                <td>{{ $ledger->date  }}</td>
            </tr>
            
        @endforeach
        
        
        
        
       
          </tbody>
    <tfoot>
            <tr>
           <th>Ledger no</th>
            <th>Account Title</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Balance</th>
            <th>Date</th>
            </tr>
        </tfoot>
    </table>
 
@stop
