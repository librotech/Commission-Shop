@extends('layouts.master')
@section('title', 'Accounts System-Users')
@section('content')
<ul class="nav nav-tabs">
     <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
      <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{ url('user/view') }}">All Users</a>
      </li>
    <li class="nav-item">
        <a class="nav-link active">Update User</a>
      </li>
     
    </ul>
<br>
<div class="col-md-12">
<h3>Update User</h3>
<hr>
@if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
        @foreach($users as $user)
            <form class="form-horizontal" method="POST" action="{{ url('user/update') }}">
                                    {{ csrf_field() }}
            <div class="row">
            <div class="col-md-3">
            <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                <label for="name">Name</label>

                
                    <input id="name" type="text" class="form-control" name="name" value="{{ $user->name }}" required autofocus>

                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                <label for="email">E-Mail Address</label>

                
                    <input id="email" type="email" class="form-control" name="email" value="{{ $user->email }}" required>

                    @if ($errors->has('email'))
                        <span class="help-block">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                    @endif
            </div>
        </div>
        <div class="col-md-3">
        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
            <label for="password">Password</label>

                <input id="password" type="text" class="form-control" value="{{ $user->password }}" name="password" required>

                @if ($errors->has('password'))
                    <span class="help-block">
                        <strong>{{ $errors->first('password') }}</strong>
                    </span>
                @endif
            </div>
        </div>
        <div class="col-md-3 col-md-offset-3">
        <div class="form-group">
            <label for="Role">Role</label>
                <select id="role"  class="form-control" name="role" required>
                    <option value="{{ $user->role }}"><?php if($user->role == 1){echo "Admin";}elseif($user->role == 2){echo "Modrator";}elseif($user->role == 3){echo"Sales";} ?></option>
                    <option value="1">Admin</option>
                    <option value="2">Modrator</option>
                    <option value="3">Sales</option>
                </select>
            </div>
        </div>
        @endforeach
        <div class="col-md-12 ">
        <div class="form-group">
            
                <button type="submit" class="btn btn-success">
                    Update User
                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
   
@endsection
