@extends('layouts.master')

@section('title', 'Accounts System-Settings')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
    <li class="nav-item">
        <a class="nav-link"  href="{{ url('/home') }}">Home</a>
    </li>
    <li class="nav-item">
        <a class="nav-link active">Settings</a>
    </li>
    
    </ul>
<br>
    <h3>Settings</h3> <!-- <a href="{{ url('supplier/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Supplier</a> -->
    <hr>
    <div class="row">
    	
    	<div class="col-md-12">
    		<table class="table table-hover table-responsive">
    	<!-- <tr>
    		<th>Shop Timings</th><td>From : 3:00 pm</td><td> To : 4:00 am</td>
    	</tr> -->
      <tr>
        <th>Set Fiscal Year</th><td><input type="text" value="{{ date('d-m-y',strtotime($fy)) }}" readonly id="datepicker" class="form-control"></td><td><button class="btn btn-info" id="setfisacl">Save</button></td>
      </tr>
      <tr>
        <th>End Year</th><td></td><td><button class="btn btn-info" id="endyear">Endyear</button></td>
      </tr>
      <tr><th>Users</th><td><a  href="{{ url('user/view') }} ">Manage Users</a></td></tr>
      <tr><th>Cash Paid Relationship</th><td><a href="{{ url('cprelation/show') }}">Cash Paid Relation</a></td></tr>
    </table>
    	</div>
    </div>
	
	
    
    
@stop
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script type="text/javascript">
  $(document).on('click','#setfisacl',function(){
        var date =$('#datepicker').val();
        var _token = $('input[name="_token"]').val();
        if(date == ""){
          alert("select date");
        }
        else{
          $.ajax({
            url:'{{ url("setfisaclyear") }}',
            type:'post',
            data:{_token:_token,date:date},
            success:function(response){
              alert(response);
            }
          });
          
        }
        
  });

  $(document).on('click','#endyear',function(){
        var _token = $('input[name="_token"]').val();
          $.ajax({
            url:'{{ url("endyear") }}',
            type:'post',
            data:{_token:_token},
            success:function(response){
              alert(response);
            }
          });        
  });
</script>
