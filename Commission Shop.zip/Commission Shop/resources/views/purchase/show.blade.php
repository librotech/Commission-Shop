
@extends('layouts.master')

@section('title', 'Accounts System-Purchase')


@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('purchase/show') }}">All Purchases Recipts</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active">Purchase bill</a>
  </li>
  
</ul>
    <h3>Purchase Bill</h3>
    <hr>
    <p class="alert alert-danger error-message" style="display:none;"></p>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif

    <form action="{{ url('purchase/save') }}" id="myForm" method="post">
        <?php
        $total=0;
        $cost_price=0;
        $duebalance=0;
        $coa=0; 
        ?>
        @foreach($bills as $bill)
    	<div class="row">
    	<div class="col-md-6">
    		<div class="form-group">
    			<label>Bill No</label>
    			<input type="number" required="required" value="{{ $bill->id }}"  class="form-control" placeholder="Enter Bill No">
    		</div>
        </div>
        <div class="col-md-6">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text"  required="required" value="{{ date('d-m-Y', strtotime($bill->created_at))}}" class="form-control" placeholder="Enter Date of Bill">
    		</div>
    	</div>
    	<div class="col-md-6">
    		<div class="form-group">
    			<label>Supplier Name</label>
                <select class="form-control" >
                    <option>{{ $bill->supplier_name }}</option>
                </select>
    		</div>
        </div>
        <div class="col-md-6">
    		<div class="form-group">
    			<label>Suplier Address</label>
    			<input type="text" value="{{ $bill->addres }}" class="form-control" placeholder="Enter Supplier Description">
    		</div>
    	</div>

    	</div>
        <?php $cost_price=$bill->advance;$duebalance=$bill->duebalance;
        $coa=$bill->coa; ?>
    @endforeach
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Product Id</th>
    				<th>Name</th>
    				<th>Cost Price</th>
    				<th>Qty</th>
    				<th>Amount</th>
                
    			</tr>
    			</thead>
    			<tbody>
    			@foreach($bill_products as $bill_product)
                <tr>
    				<td>
                    <input  class="form-control" value="{{ $bill_product->product_id }}">
                    </td>
    				<td><input value="{{ $bill_product->product_description }}" class="form-control pro_des1"></td>

    				<td><input class="form-control" value="{{ $bill_product->cost_price }}"></td>

    				<td><input type="text"  class="form-control" value="{{ $bill_product->qty }}"></td>

    				<td><input class="form-control" value="{{ $bill_product->inlinetotal }}"></td>
                    <?php
                    
                    $total +=$bill_product->inlinetotal;
                    ?>
                   
    			</tr>
                @endforeach
    		</tbody>

    	</table>
        <hr>
        <div class="row">
            <div class="col-md-8"></div>
            <div class="col-md-4">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input value="{{ $total }}"  readonly="readonly" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-4">
                <label><b>ChartofAccounts</b></label>
                <select class="form-control">
                    <option>{{ $coa }}</option>
                </select>
            </div>
            <div class="col-md-4">
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label><b>Cash Paid</b></label>
                    <input value="{{ $cost_price }}" class="form-control">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8"></div>
            <div class="col-md-4">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input value="{{ $duebalance }}" class="form-control">
                </div>
            </div>
        </div>
    </form>
@stop
