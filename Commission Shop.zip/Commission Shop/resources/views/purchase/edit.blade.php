
@extends('layouts.master')

@section('title', 'Accounts System-Purchase')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('purchase/show') }}">All Purchases Recipts</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active">Purchase bill</a>
  </li>
  
</ul><br>
    <h3>View Purchase</h3>
    <hr>
    @if(count($errors) > 0)
        @foreach($errors->all() as $error)
            <p class="alert alert-danger">{{ $error }}</p>
        @endforeach
    @endif
        @if(session()->has('message.level'))
        <div class="alert alert-{{ session('message.level') }}"> 
        {!! session('message.content') !!}
        </div>
        @endif
    <form  id="myForm" method="post">
    @foreach($bills as $bill)
    	<div class="row">
    	<div class="col-md-3">
    		<div class="form-group">
                <input type="hidden" name="bill_no" value="{{ $bill->bll_id }}" readonly="" class="form-control" placeholder="Enter Bill No">
    			<label>Bill No</label>
    			<input type="text" name="txt_bill_no" value="{{ $bill->bll_id }}" readonly="" class="form-control" placeholder="Enter Bill No">
    		</div>
        </div>
        <div class="col-md-3">
    		<div class="form-group">
    			<label>Date</label>
    			<input type="text"  value="{{ date('d-m-Y', strtotime($bill->created_at))}}" name="txt_date" readonly="" class="form-control" placeholder="Enter Date of Bill">
    		</div>
    	</div>
    	<div class="col-md-3">
    		<div class="form-group">
    			<label>Supplier Name</label>
                <select readonly="" class="form-control" name="txt_supplier" id="supplier">
                    <option value="{{ $bill->supplier_id }}">{{ $bill->supplier_name }}</option>
                </select>
    		</div>
        </div><div class="col-md-3">
    		<div class="form-group">
    			<label>Suplier Description</label>
    			<input type="text" readonly="readonly" value="{{ $bill->addres }}" id="supplier_description" name="txt_supplier_description" readonly="" class="form-control" placeholder="Enter Supplier Description">
    		</div>
    	</div>

    	</div>
        @endforeach
		<table class="table table-hover order-list">
    			<thead>
    			<tr>
    				<th>Product</th>
    				<th>Name</th>
    				<th>Cost Price</th>
    				<th>Qty</th>
    				<th>Amount</th>
                    
    			</tr>
    			</thead>
    			<tbody>
                @foreach($bill_inventories as $inventory)
                <input type="hidden" name="inventory[]" value="{{ $inventory->id }}">
                @endforeach
                @foreach($bill_products as $bill_product)
    			<tr>
    			
                    <td>
                    <input type="hidden" name="rec_id[]" value="{{ $bill_product->id }}">
                    <input type="text" readonly="" class="form-control product_id"  value="{{ $bill_product->product_id }}" list="products">
                    </td>
    				<td><input type="text" value="{{ $bill_product->product_description }}"  readonly="readonly" name="txt_product_description[]" class="form-control pro_des{{ $loop->iteration }}" placeholder="Product Description"></td>
    				<td><input type="text"  value="{{ $bill_product->cost_price }}"  readonly="" class="form-control price"></td>
    				<td><input type="number" name="qty[]" value="{{ $bill_product->qty }}" class="form-control" readonly=""></td>
    				<td><input type="number" id="ammount" value="{{ $bill_product->qty * $bill_product->cost_price }}" readonly="" class="form-control" ></td>
                    
    			</tr>
                @endforeach
    		</tbody>

    	</table>
        <hr>
        @foreach($bills as $bill)
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Total</b></label>
                    <input type="text" readonly="readonly" value="{{ $bill->total_ammount }}" id="total" name="total" readonly="" class="form-control">
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
               <!--  -->
            </div>
        </div>
        <div class="row">
            <div class="col-md-9"></div>
            <div class="col-md-3">
                <div class="form-group">
                    <label><b>Due Balance</b></label>
                    <input type="number" value="{{ $bill->total_ammount}}" readonly="readonly"  id="total_amount" name="total_amount" readonly="" class="form-control">
                </div>
            </div>
        </div>
        @endforeach
        <div class="row">
            <div class="col-md-9"></div>
           <!--  <div class="col-md-3"><button class="btn btn-block btn-info">print</button></div> -->
        </div>
        {{ csrf_field() }}
    </form>
     <br>
@stop
