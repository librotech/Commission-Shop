@extends('layouts.master')

@section('title', 'Accounts System-Project Items')

@section('content')
<ul class="nav nav-tabs">
   <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link " href="{{ url('project/createitem') }}">Create Project Item</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active">View Project Items</a>
  </li>

</ul><br>
    <h3>Project Items</h3>
    <a href="{{ url('project/createitem') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Create Project Item</a>
    <hr>
     <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
            <th>SNo.</th>
            <th>Item id</th>
            <th>Item Description</th>
            <th>Price</th>
            <th>User</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </thead>
        <tbody>
            @foreach($items as $item)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $item->id }}</td>
                <td>{{ $item->itemdescription }}</td>
                <td>{{ $item->itemprice }}</td>
                <td>{{ $item->name }}</td>
                <td>{{ date('d-m-Y', strtotime($item->created_at))}}</td>
                <td><a href="{{ url('item/show/'.$item->id)}}" class="btn btn-success btn-sm">Edit</a></td>
                @if(Auth::user()->role == 1)
                <td><a href="{{ url('item/delete/'.$item->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                @endif
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Item id</th>
            <th>Item Description</th>
            <th>Price</th>
            <th>User</th>
            <th>Date</th>
            <th>Edit</th>
            @if(Auth::user()->role == 1)
                <th>Delete</th>
            @endif
            </tr>
        </tfoot>
    </table>
@stop
