@extends('layouts.master')

@section('title', 'Accounts System-Notifications')
@section('content')
<h3>Notifications</h3>
<hr>
@foreach($notification as $noti)
<div class="alert alert-warning text text-primary">{{ $noti->message }} <span style="float:right;"><a href="dismiss/{{ $noti->id }}" class="text text-danger">Dismiss</a></span></div>
@endforeach
@stop
