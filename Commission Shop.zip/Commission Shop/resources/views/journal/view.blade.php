@extends('layouts.master')

@section('title', 'Accounts System-Journal Enteries')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active"  >View Journal Entries</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('journal/add') }}">Add New Journal Entries</a>
  </li>
</ul><br>
    <h3>All Journal Enteries</h3> <a href="{{ url('journal/add') }}" class="btn btn-info" style="float:right;margin-top:-40px;">Add New Journal Entery</a>
    <hr>

   <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        <tr>
           <th>SNo.</th>
            <th>Journal Id</th>
            <th>Date</th>
             <th>Delete</th>
            <th>void</th>
            <th>Edit</th>
        </tr>
        </thead>
        <tbody>
        @foreach($journals as $journal)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $journal->id }}</td>
                <td>{{ date('d-m-Y', strtotime($journal->created_at))}}</td>
               <td><a href="{{ url('journal/delete/'.$journal->id) }}" class="btn btn-danger btn-sm" onclick="return confirm(' you want to delete?');">Delete</a></td>
                <td><a href="{{ url('journal/void/'.$journal->id) }}" class="btn btn-primary btn-sm" onclick="return confirm(' you want to Void This Purchase journal?');">Void</a></td>
                <!--<td><a href="{{ url('journal/view/'.$journal->id) }}" class="btn btn-info btn-sm">View/Print</a></td>--> 
                 <td><a href="{{ url('journal/show/'.$journal->id)}}" class="btn btn-success btn-sm">Edit</a></td> 
            </tr>
            
        @endforeach
    </tbody>
    <tfoot>
            <tr>
            <th>SNo.</th>
            <th>Journal Id</th>
            <th>Date</th>
            <th>Delete</th>
            <th>void</th>
            <th>Edit</th>
            </tr>
        </tfoot>
    </table>
   
@stop
