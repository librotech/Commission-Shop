@extends('layouts.master')

@section('title', 'Accounts System-Fixed Accounts')

@section('content')
<ul class="nav nav-tabs">
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ url('coa/show') }}">Add New Chart Of Account</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" >Depriciate Fixed Asset</a>
  </li>
 <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
</ul><br>
    <h3>Depriciate Fixed Asset</h3>
    <hr>
    <table class="table table-hover">
        <tr>
            <th>Sno.</th>
            <th>Account Title</th>
            <th>Depriciate</th>
        </tr>
    @foreach($fixedassets as $fixedasset)
        <tr>
            <td>{{ $fixedasset->bill_id }}</td>
            <td>{{ $fixedasset->ass_name }}</td>
            <td><button type='button' data-id='{{ $fixedasset->bill_id }}' class="btn btn-info openmodel">Depriciate</button></td>
        </tr>
    
    @endforeach
    </table>
    <div id="model" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-body">
                <p><b>Are You Sure You Want To Depriciate?</b></p>
              </div>
              <div class="modal-footer">
               <a  id='yes' class="btn btn-primary">Yes</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
              </div>
            </div>

          </div>
    </div>
@stop
<script src="{{ url('/assets/js/jquery.js') }}"></script>
<script type="text/javascript">
    $(document).on('click','.openmodel',function(){
        var id=$(this).attr('data-id');
        $('#yes').attr('href','{{ url("depriciate/") }}/'+id);
        $('#model').modal('show');
    
    });
</script>