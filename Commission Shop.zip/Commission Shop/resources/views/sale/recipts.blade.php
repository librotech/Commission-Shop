@extends('layouts.master')

@section('title', 'Accounts System-sales')

@section('content')
<ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link" href="{{ url()->previous() }}">Back</a>
    </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('/home') }}">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link"  href="{{ url('coa/show') }}">View Chart Of Account</a>
  </li>
    <li class="nav-item">
    <a class="nav-link active">All CashRecieved Recipts</a>
  </li>
  
</ul>
<br>
    <h3>All CashRecieved Recipts</h3>
    <hr>
	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
        	<tr>
        		<th>SNo.</th>
        		<th>Recipt No</th>
                <th>Due Balanse</th>
        		<th>Date</th>
                <th>view</th>
        	</tr>
        </thead>
        </thead>
        <tbody>
        @foreach($cashrecieved as $crvd)
            <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $crvd->id }}</td>
                <td>{{ $crvd->total }}</td>
                <td>{{ date('d-m-Y', strtotime($crvd->created_at))}}</td>
                <td><a href="{{ url('cashrecieved/crhistory/'.$crvd->id ) }} " class="btn btn-info">View</a></td>
            </tr>
            
        @endforeach
        </tbody>
    <tfoot>
        <tr>
            <th>SNo.</th>
            <th>Recipt No</th>
            <th>Due Balanse</th>
            <th>Date</th>
            <th>view</th>
        </tr>
    </tfoot>
    </table>
  
@stop
