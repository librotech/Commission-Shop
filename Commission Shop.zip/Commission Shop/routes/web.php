<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('auth/login');
});

//purchase Routes
Route::resource('purchase/show','PurchaseController');
Route::get('purchase/add','PurchaseController@create');
Route::post('purchase/populate_supplier_description','PurchaseController@populate_supplier_description');
Route::post('purchase/products','PurchaseController@products');
Route::post('purchase/save','PurchaseController@store');
Route::get('purchase/delete/{bill_id}','PurchaseController@destroy');
Route::get('purchase/show/{bill_id}','PurchaseController@show');
Route::get('purchase/void/{bill_id}','PurchaseController@voidpurchase');
Route::post('purchase/update','PurchaseController@update');
Route::post('purchase/addsupplier','PurchaseController@addsupplier');
Route::post('purchase/addproduct','PurchaseController@addproduct');
Route::post('purchase/gettotalbalance','PurchaseController@gettotalbalance');
Route::get('purchase/payment','PurchaseController@cashpaid');
Route::post('purchase/bills','PurchaseController@supplierbills');
Route::post('purchase/bill_detail','PurchaseController@bill_detail');
Route::post('purchase/bill_products','PurchaseController@bill_products');
Route::post('purchase/cashpaid','PurchaseController@store_cashpaid');
Route::post('purchase/getsupplierbalance','PurchaseController@getsupplierbalance');


//Farmer farmer purchase
Route::resource('farmerpurchase/show','FarmerpurchaseController');
Route::get('farmerpurchase/add','FarmerpurchaseController@create');


Route::post('farmerpurchase/populate_supplier_description','FarmerpurchaseController@populate_supplier_description');
Route::post('farmerpurchase/products','FarmerpurchaseController@products');
Route::post('farmerpurchase/save','FarmerpurchaseController@store');
Route::get('farmerpurchase/delete/{bill_id}','FarmerpurchaseController@destroy');
Route::get('farmerpurchase/show/{bill_id}','FarmerpurchaseController@show');
Route::get('farmerpurchase/void/{bill_id}','FarmerpurchaseController@voidpurchase');
Route::post('farmerpurchase/update','FarmerpurchaseController@update');
Route::post('farmerpurchase/addfarmer','FarmerpurchaseController@addfarmer');
Route::post('farmerpurchase/addproduct','FarmerpurchaseController@addproduct');
Route::post('farmerpurchase/gettotalbalance','FarmerpurchaseController@gettotalbalance');
Route::get('farmerpurchase/payment','FarmerpurchaseController@cashpaid');
Route::post('farmerpurchase/bills','FarmerpurchaseController@supplierbills');
Route::post('farmerpurchase/bill_detail','FarmerpurchaseController@bill_detail');
Route::post('farmerpurchase/bill_products','FarmerpurchaseController@bill_products');
Route::post('farmerpurchase/cashpaid','FarmerpurchaseController@store_cashpaid');
Route::post('farmerpurchase/getsupplierbalance','FarmerpurchaseController@getsupplierbalance');
Route::post('farmerpurchase/credit_cash','FarmerpurchaseController@credit_cash');

//Inventory Controller Routes
Route::resource('inventory/show','InventoryController');
Route::post('inventory/search','InventoryController@search');
Route::get('single-product-inventory/show/{product_id}','InventoryController@single_product_inventory');




//products routes
Route::resource('product/show','ProductController');
Route::get('product/add','ProductController@create');
Route::post('product.store','ProductController@store');
Route::get('product/delete/{product_id}','ProductController@destroy');
Route::get('product/edit/{product_id}','ProductController@show');
Route::post('product/update','ProductController@update');
Route::get('product/allproducts','ProductController@allproducts');

//supplier routes
Route::resource('supplier/show','SupplierController');
Route::get('supplier/see/{page_id}','SupplierController@suppliers');
Route::get('supplier/add','SupplierController@create');
Route::post('supplier.store','SupplierController@store');
Route::get('supplier/delete/{supplier_id}','SupplierController@destroy');
Route::get('supplier/edit/{supplier_id}','SupplierController@show');
Route::post('supplier/update','SupplierController@update');
Route::get('supplier/allsuppliers','SupplierController@allsuppliers');

//Farmer Routes
Route::resource('farmer/show','FarmerController');
Route::get('farmer/see/{page_id}','FarmerController@farmers');
Route::get('farmer/add','FarmerController@create');
Route::post('farmer.store','FarmerController@store');
Route::get('farmer/delete/{farmer_id}','FarmerController@destroy');
Route::get('farmer/edit/{farmer_id}','FarmerController@show');
Route::post('farmer/update','FarmerController@update');
Route::get('Farmer/allfarmers','FarmerController@allfarmers');

//farmerpurchase Routes
Route::resource('farmersale/show','FarmersaleController');
Route::get('farmersale/show/{sale_id}','FarmersaleController@show');
Route::get('manualfarmerpurchase/show/{sale_id}','FarmersaleController@manualsaleshow');
Route::get('farmersale/add','FarmersaleController@create');
Route::post('farmersale/credit_cash','FarmersaleController@credit_cash');
Route::post('farmersale/save','FarmersaleController@store');
Route::get('farmersale/delete/{sale_id}','FarmersaleController@destroy');
Route::get('manualfarmerpurchase/delete/{sale_id}','FarmersaleController@mnsaledestroy');
Route::get('farmersale/void/{sale_id}','FarmersaleController@voidsale');
Route::post('farmersale/savecreditsale','FarmersaleController@savecreditsale');
Route::get('farmersale/payment','FarmersaleController@paymentrecieved');
Route::post('farmersale/customer_invoices','FarmersaleController@customer_invoices');
Route::post('farmersale/sale_invoice','FarmersaleController@sale_invoice');
Route::post('farmersale/sale_products','FarmersaleController@sale_products');
Route::post('farmersale/paymentrecieved','FarmersaleController@store_cashrecieved');

Route::get('print/{inv_id}','PrintController@printsale');
Route::get('abc','PrintController@abc');
Route::post('farmerpurchase/partybalance','FarmerController@partyBalance');


//expense Routes
Route::resource('expense/show','ExpenseController');
Route::get('expense/add','ExpenseController@create');
Route::post('expense/populate_coa_description','ExpenseController@populate_coa_description');
Route::post('expense/save','ExpenseController@store');
Route::get('expense/delete/{expense_id}','ExpenseController@destroy');
Route::get('expense/show/{expense_id}','ExpenseController@show');
Route::get('expense/void/{expense_id}','ExpenseController@voidexpense');
Route::post('expense/update','ExpenseController@update');


//Customer Routes

Route::resource('customer/show','CustomerController');
Route::get('customer/add','CustomerController@create');
Route::post('customer/save','CustomerController@store');
Route::get('customer/delete/{customer_id}','CustomerController@destroy');
Route::get('customer/show/{customer_id}','CustomerController@show');
Route::post('customer/update','CustomerController@update');
Route::post('customer/rate','CustomerController@getrate');

//sale routes
Route::resource('sale/show','SaleController');
Route::get('sale/show/{sale_id}','SaleController@show');
Route::get('manualsale/show/{sale_id}','SaleController@manualsaleshow');
Route::get('sale/add','SaleController@create');
Route::post('sale/credit_cash','SaleController@credit_cash');
Route::post('sale/save','SaleController@store');
Route::get('sale/delete/{sale_id}','SaleController@destroy');
Route::get('manualsale/delete/{sale_id}','SaleController@mnsaledestroy');
Route::get('sale/void/{sale_id}','SaleController@voidsale');
Route::post('sale/savecreditsale','SaleController@savecreditsale');
Route::get('sale/payment','SaleController@paymentrecieved');
Route::post('sale/customer_invoices','SaleController@customer_invoices');
Route::post('sale/sale_invoice','SaleController@sale_invoice');
Route::post('sale/sale_products','SaleController@sale_products');
Route::post('sale/paymentrecieved','SaleController@store_cashrecieved');

Route::get('print/{inv_id}','PrintController@printsale');
Route::get('abc','PrintController@abc');
Route::post('sale/partybalance','SaleController@partyBalance');


Route::group(['middleware' => 'admin'], function () {
//Chart Of Accounts Routes

Route::resource('coa/show','ChartofaccountController');
Route::get('coa/add','ChartofaccountController@create');
Route::post('coa/store','ChartofaccountController@store');
Route::get('coa/delete/{chartofaccount_id}','ChartofaccountController@destroy');
Route::get('coa/edit/{chartofaccount_id}','ChartofaccountController@show');
Route::post('coa/update','ChartofaccountController@update');
Route::get('coa/accountdetails/{acc_id}','ChartofaccountController@account_details');
Route::get('ledgerentries/show/{ledger_id}','ChartofaccountController@ledgerentries');
Route::get('fundstransfer/show/{fund_id}','ChartofaccountController@ledgerentries');
Route::get('expense/view/{expense_id}','ChartofaccountController@ledgerentries');
Route::get('purchase/view/{purchase_id}','ChartofaccountController@ledgerentries');
Route::get('sales/view/{sale_id}','ChartofaccountController@ledgerentries');
Route::get('debitnotes/view/{debit_id}','ChartofaccountController@ledgerentries');
Route::get('creditnotes/view/{debit_id}','ChartofaccountController@ledgerentries');
Route::get('coa/tradepayable','ChartofaccountController@tradepayable');
Route::get('coa/traderecieveable','ChartofaccountController@traderecieveable');
Route::post('coa/addfixaccount','ChartofaccountController@addfixedaccount');
Route::get('depriciate','ChartofaccountController@showdepriciatefa');
Route::get('depriciate/{fa_id}','ChartofaccountController@depriciatefa');
//cashrecieved
Route::get('customer/recipts/{customer_id}','ChartofaccountController@cashrecieved');
Route::get('cashrecieved/crhistory/{cashrecieved_id}','ChartofaccountController@cashrecievedhistory');

//cashpaid
Route::get('supplier/bills/{supplier_id}','ChartofaccountController@cashpaid');
Route::get('cashpaid/history/{cashpaid_id}','ChartofaccountController@cashpaidhistory');



//Journal Routes
Route::resource('journal/show','JournalenteryController');
Route::get('journal/add','JournalenteryController@create');
Route::post('journal/coas','JournalenteryController@populatecoanameandtype');
Route::post('journal/save','JournalenteryController@store');
Route::get('journal/delete/{jounal_id}','JournalenteryController@destroy');
Route::get('journal/void/{jounal_id}','JournalenteryController@voidjournal');
Route::get('journal/show/{jounal_id}','JournalenteryController@show');
Route::post('journal/update','JournalenteryController@update');
Route::get('journal/view/{jounal_id}','JournalenteryController@view');

//ledger routes
Route::get('ledger/show','JournalenteryController@ledgerdemo');

//cash paid Relation
Route::resource('cprelation/show','CprelationController');
Route::post('cprelation/add','CprelationController@store');
Route::get('cprelation/delete/{cpr_id}','CprelationController@destroy');


//funds transfer

Route::resource('fundtransfer/show','FundstransferController');
Route::get('fundstranser/add','FundstransferController@create');
Route::post('fundtransfer/add','FundstransferController@store');


//debitnotes
Route::resource('debitnotes/view','DebitnoteController');
Route::get('debitnotes/add','DebitnoteController@create');
Route::post('debitnotes/getsupbills','DebitnoteController@getsupbills');
Route::post('debitnotes/getbillproducts','DebitnoteController@getbillproducts');
Route::post('debitnotes/getproductcostprice','DebitnoteController@getproductcostprice');

Route::post('debitnotes/save','DebitnoteController@store');
Route::get('debitnote/void/{debit_note_id}','DebitnoteController@voiddebitnotes');

//credit_notes
 Route::resource('creditnotes/view','CreditnoteController');
 Route::get('creditnotes/add','CreditnoteController@create');
 Route::post('creditnotes/save','CreditnoteController@store');
 Route::get('creditnote/void/{credit_note_id}','CreditnoteController@voidcreditnotes');
 Route::post('creditnotes/getcusbills','CreditnoteController@getcusbills');
 Route::post('creditnotes/getbillproducts','CreditnoteController@getbillproducts');
 //report routes
Route::resource('report/view','ReportController');
Route::get('report/dailycashsalereport','ReportController@dailycashsalereport');
Route::get('report/weeklycashsalereport','ReportController@weeklycashsalereport');
Route::get('report/monthlycashsalereport','ReportController@monthlycashsalereport');
Route::post('report/datecashsalereport','ReportController@datecashsalereport');
Route::get('report/dailyexpensereport','ReportController@dailyexpensereport');
Route::get('report/weeklybalancereport','ReportController@weeklybalancereport');
Route::get('report/monthlybalancereport','ReportController@monthlybalancereport');\
Route::post('report/dateexpensereport','ReportController@dateexpensereport');
Route::get('dailycashsales','ReportController@dailycashsales');
Route::get('weeklycashsales','ReportController@weeklycashsales');
Route::get('monthlycashsales','ReportController@monthlycashsales');
Route::get('dailyexpenses','ReportController@dailyexpenses');
Route::get('weeklyexpenses','ReportController@weeklyexpenses');
Route::get('monthlyexpenses','ReportController@monthlyexpenses');
Route::get('profitandlossreport','ReportController@plreport');
Route::get('balancesheetreport','ReportController@balancesheetreport');
Route::get('trialbalance','ReportController@trialbalance');

Route::post('report/populate_supplier_description','ReportController@populate_supplier_description');
Route::post('report/populate_customer_description','ReportController@populate_customer_description');
Route::post('report/populate_product_description','ReportController@populate_product_description');
Route::post('report/populate_product','ReportController@populate_product');

Route::post('report/populate_sales','ReportController@populate_sales');

Route::get('purchase_report','ReportController@purchase_report');
Route::get('sales_report','ReportController@sales_report');
Route::get('stock_report','ReportController@stock_report');

Route::get('weeklybalancesheet','ReportController@weeklybalancesheet');
Route::get('dailybalancesheet','ReportController@dailybalancesheet');
Route::get('monthlybalancesheet','ReportController@monthlybalancesheet');
Route::post('datetodate','ReportController@datetodate');
Route::get('weeklyplreport','ReportController@weeklyplreport');
Route::get('dailyplreport','ReportController@dailyplreport');
Route::get('monthlyplreport','ReportController@monthlyplreport');
Route::post('datetodatepl','ReportController@datetodatepl');
Route::get('machinestitch/show','ReportController@machinestitch');
Route::get('Employeestitch/show','ReportController@Employeestitch');
Route::get('report/dailymachinstitches','ReportController@dailymachinstitches');
Route::get('report/monthlymachinstitches','ReportController@monthlymachinstitches');

Route::get('ledgercoareport','ReportController@ledgercoareport');
Route::post('reports/coalegreport','ReportController@coalegreport');
Route::get('report/dailyemployeestitches','ReportController@dailyemployeestitches');
Route::get('report/monthlyemployeestitches','ReportController@monthlyemployeestitches');

Route::post('employee/getcustomerbalance','EmployeeController@getcustomerbalance');

Route::post('trialbalancebydate','ReportController@trialBalanceByDate');


//user Routes
Route::resource('user/view','UserController');
Route::get('user/add','UserController@create');
Route::post('user/store','UserController@store');
Route::get('user/delete/{user_id}','UserController@destroy');
Route::get('user/show/{user_id}','UserController@show');
Route::post('user/update','UserController@update');
//setting routes
Route::resource('settings','SettingController');
Route::post('setfisaclyear','SettingController@setfisaclyear');
Route::post('endyear','SettingController@endyear');


});



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('notification','HomeController@notification');
Route::get('dismiss/{notification_id}','HomeController@dismiss');




//employees Routes
Route::resource('employee/view','EmployeeController');
Route::get('employee/alotmachine','EmployeeController@alotmachine');
Route::get('employee/add','EmployeeController@create');
Route::post('employee/store','EmployeeController@store');
Route::get('employee/delete/{user_id}','EmployeeController@destroy');
Route::get('employee/show/{employee_id}','EmployeeController@show');
Route::post('employee/update','EmployeeController@update');
Route::get('employee/attendence','EmployeeController@showattendenceform');
Route::post('employee/showattenedce','EmployeeController@showattenedce');
Route::get('employee/showattenedcebydate','EmployeeController@showattenedcebydate');
Route::post('employee/allattendence','EmployeeController@allattendence');
Route::get('employee/updateattendecs/{employee_id}/{date}/{status}','EmployeeController@updateattendecs');

Route::post('employee/doattendence','EmployeeController@doattendencefromattendenceform');
Route::post('employee/salaryledger','EmployeeController@salaryledgerfromattendenceform');
Route::post('employee/showmachine','EmployeeController@showmachine');
Route::post('employee/savemachin','EmployeeController@savemachin');
Route::get('employee/stichesform','EmployeeController@stichesform');
Route::post('employee/empmachin','EmployeeController@empmachin');
Route::post('employee/storestich','EmployeeController@storestich');
Route::get('employees/editstitchform','EmployeeController@editstitchform');
Route::post('employee/employeestitches','EmployeeController@employeestitches');
Route::post('employee/updatestitch','EmployeeController@updatestitch');
Route::get('employee/stichingunit','EmployeeController@stichingunit');
Route::get('stitchinv/view','EmployeeController@viewstitchinv');

Route::post('stitching/bill','EmployeeController@stichingbill');

Route::get('employee/stichingunit/{inv_id}','PrintController@stichprint');
Route::post('employee/customer_invoices','EmployeeController@customer_invoices');
Route::post('employee/stich_invoice','EmployeeController@stich_invoice');
Route::post('employee/stich_items','EmployeeController@stich_items');
Route::get('employees/returnsaleview','EmployeeController@returnsaleview');
Route::post('employee/returnsale','EmployeeController@returnsale');
Route::get('employee/advance','EmployeeController@showadvanceform');
Route::post('employee/storeadvance','EmployeeController@storeadvance');
Route::get('employee/payslip','EmployeeController@employeepayslip');
Route::post('employee/employeepaydetails','EmployeeController@employeepaydetails');

Route::post('stitch/designdetail','EmployeeController@getdesigndetails');
Route::post('employee/employeesbyshift','EmployeeController@employeesbyshift');
Route::post('updateshift','EmployeeController@updateShift');
Route::post('updatesingleshift','EmployeeController@updateSingleShift');
//pay role Routes

Route::resource('payroll/add','PayrollController');

Route::post('payroll/getemplyeesalary','PayrollController@getemplyeesalary');

Route::post('payroll/payadvance','PayrollController@payadvance');

Route::post('payroll/savepayroll','PayrollController@savepayroll');
Route::post('bonus/save','PayrollController@saveBonus');


//Construction views
Route::resource('project/view','ConstructionController');
Route::get('project/add','ConstructionController@create');
Route::post('construction/save','ConstructionController@store');
Route::get('project/delete/{project_id}','ConstructionController@destroy');
Route::get('project/show/{project_id}','ConstructionController@show');
Route::post('project/update','ConstructionController@update');
Route::get('project/createitem','ConstructionController@createitem');
Route::post('create/item','ConstructionController@saveitem');
Route::get('project/itemview','ConstructionController@allitems');
Route::get('item/delete/{item_id}','ConstructionController@destroyitem');
Route::get('item/show/{item_id}','ConstructionController@showitem');
Route::post('update/item','ConstructionController@updateitem');
Route::get('project/alotitem','ConstructionController@alotitem');
Route::post('alot/item','ConstructionController@alotitems');
Route::get('project/viewaloteditems','ConstructionController@viewaloteditems');

//project expense
Route::get('pexpense/add','ConstructionController@pexpenseform');
Route::post('pepense/save','ConstructionController@savepexpense');
Route::get('pexpense/view','ConstructionController@viewpexpense');
Route::get('pexpense/delete/{pexp_id}','ConstructionController@destroyexpense');
Route::get('pexpense/show/{pexp_id}','ConstructionController@showapproveexpense');
Route::post('pexpense/updatepexpense','ConstructionController@updatepexpense');

//Design Routes
Route::resource('design/add','DesignController');
Route::post('Design/store','DesignController@store');
Route::get('Design/view','DesignController@show');
Route::get('design/delete/{dc}','DesignController@destroy');
Route::get('design/show/{dc}','DesignController@edit');
Route::post('Design/edit','DesignController@update');



